pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        maven("https://chaquo.com/maven")      // สำรอง: ถ้า Maven Central หา Chaquopy ไม่เจอชั่วคราว
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven("https://chaquo.com/maven")
    }
}
rootProject.name = "AiBot"
include(":app")
project(":app").projectDir = file("aibot-app/app")   // เปิดโฟลเดอร์นอกสุดก็ build ได้
