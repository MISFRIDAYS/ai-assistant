"""ทดสอบความเสถียร: จำกัดการถอดเสียงแบบเสียเงินตอนรอคำปลุก"""
import os
import sys
import tempfile
import unittest
from unittest import mock

os.environ.update({"MOCK_PHONE": "1", "ANTHROPIC_API_KEY": "test", "TELEGRAM_BOT_TOKEN": "test",
                   "ALLOWED_USER_IDS": "111"})
os.environ.setdefault("SHARED_STORAGE", tempfile.mkdtemp())
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config  # noqa: E402


class TestWakeSttCap(unittest.TestCase):
    def setUp(self):
        import voice
        self.v = voice
        voice._nano_wake.clear()
        self.p = [mock.patch.object(config, "MOCK_PHONE", False),
                  mock.patch.object(voice, "NANO_WAKE_PER_HOUR", 2),
                  mock.patch.object(voice, "stt_chain", return_value=["nano"]),
                  mock.patch.object(voice, "_transcribe_nano", return_value="สวัสดี")]
        for x in self.p:
            x.start()

    def tearDown(self):
        for x in self.p:
            x.stop()

    def test_wake_capped_per_hour(self):
        out = [self.v.transcribe("x.wav", wake=True) for _ in range(4)]
        self.assertEqual(out, ["สวัสดี", "สวัสดี", "", ""])

    def test_commands_never_capped(self):
        for _ in range(3):
            self.v.transcribe("x.wav", wake=True)
        self.assertEqual(self.v.transcribe("x.wav"), "สวัสดี")      # คำสั่งจริงหลังเรียกผู้ช่วย → ถอดได้เสมอ

    def test_free_engine_not_counted(self):
        with mock.patch.object(self.v, "stt_chain", return_value=["groq", "nano"]), \
                mock.patch.object(self.v, "_transcribe_groq", return_value="ผู้ช่วย"):
            for _ in range(5):
                self.assertEqual(self.v.transcribe("x.wav", wake=True), "ผู้ช่วย")
        self.assertEqual(len(self.v._nano_wake), 0)


if __name__ == "__main__":
    unittest.main()
