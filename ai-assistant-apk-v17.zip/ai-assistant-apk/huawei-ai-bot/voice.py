"""เสียง: แปลงเสียงเป็นข้อความ (Groq Whisper) และข้อความเป็นเสียงพูดภาษาไทย (Google TTS ผ่าน gTTS)

ใช้ได้แม้เครื่อง Huawei ไม่มีโปรแกรมเสียงพูด (TTS engine) ในตัว
"""
import math
import os
import json
import re
import shutil
import struct
import subprocess
import threading
import time
import wave

import requests

import config

GROQ_URL = "https://api.groq.com/openai/v1/audio/transcriptions"

# ประโยคที่ Whisper ชอบ "หลอน" ออกมาเองตอนเงียบ
_HALLUCINATIONS = {
    "ขอบคุณครับ", "ขอบคุณค่ะ", "ขอบคุณที่รับชม", "ขอบคุณที่รับชมครับ", "ขอบคุณที่รับชมค่ะ",
    "ติดตามช่องของเราด้วยนะคะ", "subscribe", "thank you", "thanks for watching", "you", ".", "",
    "ฝากกดไลค์กดแชร์กดซับสไครบ์ด้วยนะครับ", "ซับไตเติ้ลโดย", "สวัสดีครับ ขอบคุณครับ",
}


# ประโยคที่ระบบถอดเสียงชอบ "แต่งขึ้นเอง" ตอนได้ยินแค่เสียงรบกวน
_HALLU_RX = re.compile(r"(ขอบคุณ(ที่|สำหรับการ)?รับชม|ติดตาม(ช่อง|ชม)|กด(ไลค์|ไลก์|แชร์|ซับ|ติดตาม)|ซับสไครบ์|subscribe|"
                       r"ซับไตเติ้ล|คำบรรยาย(โดย)?|แปลโดย|thanks? (you )?for watching|amara\.org|"
                       r"^\W*(อืม+|เอ่อ+|อ่า+|ฮะ|ห๊ะ|หือ|ฮือ|อ้า|โอ้|ว้าว|you|bye)\W*$)", re.I)


def _norm_t(t):
    return re.sub(r"[\s.,!?'\"“”()\-]+", "", (t or "").lower())


_MOJI = re.compile(r"[àÃâ][\u0080-\u00BF¸¹º]")


def fix_mojibake(text):
    """ไทยที่ถูกอ่านผิดรหัส (UTF-8 → Latin-1) เช่น 'à¸ªà¸§à¸±à¸ª' → 'สวัส' — กู้กลับเป็นภาษาไทย"""
    t = text or ""
    if not _MOJI.search(t):
        return t
    for enc in ("latin-1", "cp1252"):
        try:
            fixed = t.encode(enc).decode("utf-8")
            if re.search(r"[\u0E00-\u0E7F]", fixed):
                return fixed
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue
    try:
        return t.encode("latin-1", "ignore").decode("utf-8", "ignore") or t
    except Exception:  # noqa: BLE001
        return t


def _json_utf8(r):
    """อ่าน JSON เป็น UTF-8 เสมอ (บางครั้งเซิร์ฟเวอร์ไม่บอก charset → ไลบรารีเดาเป็น Latin-1 → ไทยเพี้ยน)"""
    c = getattr(r, "content", None)
    if isinstance(c, (bytes, bytearray)):
        return json.loads(c.decode("utf-8", "replace"))
    return r.json()


def is_hallucination(text, prompt=""):
    """ข้อความนี้น่าจะไม่ใช่คนพูดจริง (เสียงรบกวน → ระบบแต่งประโยคขึ้นเอง)"""
    t = (text or "").strip()
    if not t or t.lower().strip(" .!") in _HALLUCINATIONS or _HALLU_RX.search(t):
        return True
    n = _norm_t(t)
    if len(n) < 2:
        return True
    # ตัวอักษรภาษาอื่นที่ไม่ใช่ไทย/อังกฤษ (จีน ญี่ปุ่น เกาหลี รัสเซีย อาหรับ ฮินดี ฯลฯ) = ถอดเสียงเพี้ยน
    foreign = len(re.findall(r"[\u0400-\u04FF\u0590-\u06FF\u0900-\u0DFF\u0E80-\u0EFF\u1000-\u109F"
                             r"\u3040-\u30FF\u3400-\u9FFF\uAC00-\uD7AF\u00C0-\u024F]", t))
    if foreign >= 2 and foreign >= len(n) * 0.2:
        return True
    if re.search(r"(.{2,6})\1{3,}", n):                  # คำซ้ำวนๆ "เปิดเปิดเปิดเปิด"
        return True
    pn = _norm_t(prompt)
    if pn and len(n) >= 4 and n in pn:                     # ท่องคำใบ้ (ชื่อแอป/ชื่อคน) ออกมาเอง
        return True
    return False


class VoiceError(Exception):
    pass


def _api(args, **kw):
    """เรียก Termux:API ทีละคำสั่ง (กันชนกันจนขึ้น error สีแดง) และไม่ตัดกลางคัน"""
    import termux_lock
    kw["timeout"] = max(kw.get("timeout", 30), 60)
    kw.setdefault("capture_output", True)
    with termux_lock.termux_api():
        return subprocess.run(args, **kw)


# ---------------------------------------------------------------- เสียง → ข้อความ

def stt_available():
    return bool(config.GROQ_API_KEY)


def transcribe(path):
    """คืนข้อความจากไฟล์เสียง (m4a/ogg/mp3/wav) หรือ "" ถ้าไม่มีเสียงพูด"""
    if config.MOCK_PHONE:
        return "ทดสอบ"
    if not config.GROQ_API_KEY:
        raise VoiceError("ยังไม่ได้ใส่ GROQ_API_KEY ในไฟล์ .env (สมัครฟรีที่ console.groq.com)")
    name = os.path.basename(path)
    if name.endswith(".oga"):
        name = name[:-4] + ".ogg"
    prompt = _stt_prompt()
    with open(path, "rb") as f:
        r = _session("groq").post(
            GROQ_URL,
            headers={"Authorization": f"Bearer {config.GROQ_API_KEY}"},
            files={"file": (name, f)},
            data={"model": config.STT_MODEL, "language": "th", "temperature": "0",
                  "response_format": "verbose_json", "prompt": prompt},
            timeout=60,
        )
    if r.status_code != 200:
        raise VoiceError(f"Groq {r.status_code}: {r.text[:300]}")
    data = _json_utf8(r)
    text = fix_mojibake((data.get("text") or "").strip())
    segs = data.get("segments") or []
    if segs:
        # ความมั่นใจว่ามีคนพูดจริง: no_speech สูง / logprob ต่ำมาก / ข้อความวนซ้ำ = เสียงรบกวน
        nsp = min(float(x.get("no_speech_prob", 0) or 0) for x in segs)
        lp = max(float(x.get("avg_logprob", 0) or 0) for x in segs)
        cr = max(float(x.get("compression_ratio", 0) or 0) for x in segs)
        _last["no_speech"], _last["logprob"] = round(nsp, 2), round(lp, 2)
        if nsp > 0.6 or lp < -1.0 or cr > 2.6:
            print(f"🔇 ไม่ใช่เสียงพูด (no_speech={nsp:.2f} logprob={lp:.2f}) ทิ้ง: {text[:40]!r}", flush=True)
            return ""
    if is_hallucination(text, prompt):
        print(f"🔇 ข้อความแต่งเอง ทิ้ง: {text[:40]!r}", flush=True)
        return ""
    return text


def transcribe_segments(path):
    """ถอดเสียงพร้อมเวลา (สำหรับทำซับ) คืน [{"start", "end", "text"}]"""
    if config.MOCK_PHONE:
        return [{"start": 0.0, "end": 1.5, "text": "ทดสอบซับ"}]
    if not config.GROQ_API_KEY:
        raise VoiceError("ต้องใส่ GROQ_API_KEY ก่อน")
    with open(path, "rb") as f:
        r = _session("groq").post(
            GROQ_URL, headers={"Authorization": f"Bearer {config.GROQ_API_KEY}"},
            files={"file": (os.path.basename(path), f)},
            data={"model": config.STT_MODEL, "language": "th", "temperature": "0",
                  "response_format": "verbose_json"}, timeout=300)
    if r.status_code != 200:
        raise VoiceError(f"Groq {r.status_code}: {r.text[:300]}")
    segs = _json_utf8(r).get("segments") or []
    return [{"start": float(s["start"]), "end": float(s["end"]), "text": fix_mojibake(s.get("text", ""))}
            for s in segs if (s.get("text") or "").strip() and s.get("no_speech_prob", 0) < 0.8]


# ---------------------------------------------------------------- ข้อความ → เสียง

def clean_for_speech(text, limit=600):
    t = re.sub(r"https?://\S+", "", text)
    t = re.sub(r"📎 แหล่งที่มา:.*", "", t, flags=re.S)
    t = re.sub(r"[*_`#>|]", "", t)
    t = re.sub(r"^\s*[-•]\s*", "", t, flags=re.M)
    t = re.sub(r"[\U0001F000-\U0001FAFF☀-➿️✅❗⚠]", "", t)  # อีโมจิ
    t = re.sub(r"฿\s*([\d,.]+)", r"\1 บาท", t)                  # ฿158 → 158 บาท
    t = re.sub(r"\$\s*([\d,.]+)", r"\1 ดอลลาร์", t)
    t = re.sub(r"(\d)\s*°\s*C", r"\1 องศา", t)
    t = re.sub(r"(\d)\s*%", r"\1 เปอร์เซ็นต์", t)
    t = re.sub(r"\s*[≈~]\s*", " ประมาณ ", t)
    t = re.sub(r"\s*&\s*", " และ ", t)
    t = re.sub(r"\(([^)]{0,40})\)", r", \1,", t)                # วงเล็บ → เว้นจังหวะ
    t = re.sub(r"[\[\]{}<>=+^\\]", " ", t)
    t = re.sub(r"\s+", " ", t).strip(" ,")
    return t[:limit]


_clean = {"t": 0.0, "lock": threading.Lock()}


def _cleanup_old():
    """ลบไฟล์เสียงเก่าเกิน 10 นาที (ทำนาทีละครั้ง และกันชนกันหลาย thread)"""
    if time.time() - _clean["t"] < 60 or not _clean["lock"].acquire(blocking=False):
        return
    try:
        _clean["t"] = time.time()
        for old in os.listdir(config.DATA_DIR):
            if not old.startswith("tts_"):
                continue
            fp = os.path.join(config.DATA_DIR, old)
            try:
                if time.time() - os.path.getmtime(fp) > 600:
                    os.remove(fp)
            except OSError:
                pass
    finally:
        _clean["lock"].release()


def synthesize(text, path=None):
    """สร้างไฟล์ mp3 เสียงพูดภาษาไทย คืน path"""
    try:
        import voice_profile
        voice_profile.sync()                  # เสียงที่เลือกด้วย /voice (อาจเลือกจากอีกโปรเซส)
    except Exception:  # noqa: BLE001
        pass
    text = clean_for_speech(text)
    if not text:
        raise VoiceError("ไม่มีข้อความให้พูด")
    path = path or os.path.join(config.DATA_DIR, f"tts_{int(time.time() * 1000)}.mp3")
    _cleanup_old()
    if config.MOCK_PHONE:
        with open(path, "wb") as f:
            f.write(b"ID3mock")
        return path
    if config.TTS_ENGINE == "gemini" and config.GEMINI_API_KEY and time.time() >= _gem_err["until"]:
        try:
            _gemini_tts(text, path)        # เหมือนคนที่สุด (กำหนดน้ำเสียงได้) แต่ช้ากว่า
            if os.path.getsize(path) > 500:
                return path
        except Exception as e:  # noqa: BLE001
            _gem_err["until"] = time.time() + (3600 if "429" in str(e) or "quota" in str(e).lower() else 300)
            print(f"⚠️ เสียง Gemini ใช้ไม่ได้ ใช้เสียง Microsoft แทนชั่วคราว: {str(e)[:120]}", flush=True)
    if _edge_err.get("fails", 0) >= 3 and time.time() - _edge_err.get("t", 0) > 600:
        _edge_err["fails"] = 0                       # ลองเสียงคนใหม่ทุก 10 นาที (เน็ตหลุดชั่วคราว)
    if config.TTS_ENGINE in ("edge", "gemini") and _edge_err.get("fails", 0) < 3:
        try:
            _edge_tts(text, path)          # เสียงคนจริง (Microsoft Neural) เป็นธรรมชาติกว่ามาก
            if os.path.getsize(path) > 500:
                _edge_err["fails"] = 0
                return path
        except Exception as e:  # noqa: BLE001
            _edge_err["fails"] = _edge_err.get("fails", 0) + (3 if isinstance(e, ImportError) else 1)
            _edge_err["t"] = time.time()
            _note_edge_error(e)
    try:
        audio = _google_tts(text)          # สำรอง: Google (เสียงแข็งกว่า)
        with open(path, "wb") as f:
            f.write(audio)
        return path
    except Exception:  # noqa: BLE001
        pass
    try:
        from gtts import gTTS
    except ImportError as e:
        raise VoiceError("ยังไม่ได้ติดตั้ง gTTS: pip install gTTS") from e
    gTTS(text=text, lang=config.TTS_LANG).save(path)
    return path


_edge_err = {"shown": False}
_gem_err = {"until": 0.0}


def _gemini_tts(text, path):
    """Gemini TTS: ได้ PCM 24kHz → WAV → แปลงเป็น mp3 ถ้ามี ffmpeg (ส่ง Telegram ได้)"""
    import base64
    import subprocess
    import wave
    import gemini_client
    body = {"contents": [{"parts": [{"text": f"{config.TTS_STYLE}: {text}"}]}],
            "generationConfig": {"responseModalities": ["AUDIO"], "speechConfig": {
                "voiceConfig": {"prebuiltVoiceConfig": {"voiceName": config.GEMINI_TTS_VOICE}}}}}
    data = gemini_client._post(config.GEMINI_TTS_MODEL, body, timeout=60)
    parts = ((data.get("candidates") or [{}])[0].get("content") or {}).get("parts") or []
    inline = next((p["inlineData"] for p in parts if p.get("inlineData")), None)
    if not inline:
        raise VoiceError("Gemini ไม่ได้ส่งเสียงกลับมา")
    rate = int((re.search(r"rate=(\d+)", inline.get("mimeType", "")) or [0, 24000])[1])
    wav = path.rsplit(".", 1)[0] + ".wav"
    with wave.open(wav, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(base64.b64decode(inline["data"]))
    if path.endswith(".mp3") and shutil.which("ffmpeg"):
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-b:a", "64k", path], timeout=30)
        if os.path.exists(path) and os.path.getsize(path) > 500:
            os.remove(wav)
            return
    os.replace(wav, path)                     # เล่นได้ทั้ง play-audio/termux-media-player


def _note_edge_error(e):
    if not _edge_err["shown"]:
        _edge_err["shown"] = True
        print(f"⚠️ เสียงแบบคน (edge-tts) ใช้ไม่ได้ → ใช้เสียง Google แทน: {e}", flush=True)


def _edge_tts(text, path):
    """Microsoft Edge Neural TTS (ฟรี) — th-TH-NiwatNeural (ชาย) / th-TH-PremwadeeNeural (หญิง)"""
    try:
        import asyncio
        import edge_tts
    except ImportError:                       # แอป APK: ไม่มี edge-tts/aiohttp → ใช้ตัวที่เขียนเอง
        import edge_ws
        edge_ws.synth(text, path, config.TTS_VOICE, config.TTS_RATE, config.TTS_PITCH)
        return

    async def go():
        c = edge_tts.Communicate(text, config.TTS_VOICE, rate=config.TTS_RATE, pitch=config.TTS_PITCH)
        with open(path, "wb") as f:
            async for chunk in c.stream():
                if chunk.get("type") == "audio":
                    f.write(chunk["data"])
    asyncio.run(go())


_sessions = {}


def _session(name):
    """การเชื่อมต่อที่เปิดค้างไว้ใช้ซ้ำ (ประหยัดเวลาเชื่อมต่อ HTTPS ใหม่ ~0.3-0.5 วินาทีต่อครั้ง)"""
    s = _sessions.get(name)
    if s is None:
        s = _sessions[name] = requests.Session()
    return s


def _google_tts(text):
    """เรียก Google TTS ตรง (วิธีเดียวกับ gTTS) ผ่าน session ที่เปิดค้างไว้ ท่อนละไม่เกิน 100 ตัวอักษร"""
    import base64
    import json
    import urllib.parse
    s = _session("tts")
    s.headers.update({"User-Agent": "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36",
                      "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"})
    out = b""
    parts = [text[i:i + 100] for i in range(0, len(text), 100)]
    for part in parts:
        param = json.dumps([part, config.TTS_LANG, None, "null"], separators=(",", ":"))
        rpc = json.dumps([[["jQ1olc", param, None, "generic"]]], separators=(",", ":"))
        r = s.post("https://translate.google.com/_/TranslateWebserverUi/data/batchexecute",
                   data=f"f.req={urllib.parse.quote(rpc)}&", timeout=10)
        m = re.search(r'jQ1olc","\[\\"(.*?)\\"]', r.text)
        if r.status_code != 200 or not m:
            raise VoiceError(f"Google TTS {r.status_code}")
        out += base64.b64decode(m.group(1))
    return out


def warmup():
    """เปิดการเชื่อมต่อไว้ล่วงหน้า (ให้ครั้งแรกไม่ช้า) — เรียกใน thread แยก"""
    def _w():
        import voice_profile
        p = voice_profile.pol()
        for phrase in (p, f"ได้{p}", f"ได้เลย{p}", f"โอเค{p}", f"จัดให้{p}", f"ไว้คุยกันใหม่นะ{p}"):   # เตรียมเสียงไว้
            try:
                _cached(phrase)
            except Exception:  # noqa: BLE001
                pass
        for fn in (lambda: _google_tts("ครับ"),
                   lambda: _session("groq").get("https://api.groq.com/openai/v1/models",
                                                headers={"Authorization": f"Bearer {config.GROQ_API_KEY}"},
                                                timeout=10)):
            try:
                fn()
            except Exception:  # noqa: BLE001
                pass
    if not config.MOCK_PHONE:
        threading.Thread(target=_w, daemon=True).start()


def _player():
    if config.ANDROID_APP:
        return "app"
    if shutil.which("play-audio"):
        return "play-audio"
    if shutil.which("termux-media-player"):
        return "termux-media-player"
    return None


def play(path, wait=True, mute_mic=True):
    """เล่นไฟล์เสียงออกลำโพงของเครื่อง
    mute_mic=True: ไมค์หยุดฟังระหว่างเล่น (กันได้ยินเสียงตัวเอง)
    mute_mic=False: ไมค์ฟังต่อ (ใช้กับคำสั้นๆ อย่าง "ครับ" → ผู้ใช้พูดต่อได้ทันที)"""
    import audio_stream
    if config.MOCK_PHONE:
        return
    if mute_mic:
        audio_stream.mark_speaking(True)
    try:
        _play(path, wait)
    finally:
        if mute_mic:
            audio_stream.mark_speaking(False)


def ack(text=None):
    """ตอบรับสั้นๆ แบบไม่บล็อก และไม่ปิดไมค์ → ผู้ใช้พูดคำสั่งต่อได้เลยไม่ต้องรอ"""
    if text is None:
        import voice_profile
        text = voice_profile.pol()

    def _go():
        try:
            play(_cached(text), mute_mic=False)
        except Exception:  # noqa: BLE001
            pass
    threading.Thread(target=_go, daemon=True).start()


_current = {"proc": None}


def stop_playing():
    """หยุดเสียงที่กำลังพูดอยู่ทันที (ใช้ตอนผู้ใช้พูดแทรก)"""
    _current["cancel_at"] = time.time()
    proc = _current.get("proc")
    if proc and proc.poll() is None:
        try:
            proc.kill()
        except Exception:  # noqa: BLE001
            pass
    if _player() == "termux-media-player":
        _api(["termux-media-player", "stop"])
    elif _player() == "app":
        import android_shim
        android_shim.bridge().stopPlay()


def _play(path, wait=True):
    p = _player()
    if p == "app":
        import android_shim
        if not path or not os.path.exists(path) or os.path.getsize(path) < 200:
            print(f"🔇 ไม่มีไฟล์เสียง ข้ามการพูด: {path}", flush=True)
            return
        android_shim.bridge().play(path, bool(wait))
        return
    if p == "play-audio":
        proc = subprocess.Popen(["play-audio", path])
        _current["proc"] = proc
        if wait:
            proc.wait(timeout=180)
    elif p == "termux-media-player":
        _api(["termux-media-player", "play", path])
        if wait:
            time.sleep(0.8)
            for _ in range(360):
                info = _api(["termux-media-player", "info"],
                                      text=True, timeout=10).stdout
                if "Playing" not in info:
                    break
                time.sleep(0.5)
    else:
        raise VoiceError("ไม่มีโปรแกรมเล่นเสียง: pkg install play-audio")


def _chunks(text, first=45, size=110):
    """แบ่งข้อความเป็นท่อนสั้นๆ (ท่อนแรกสั้นสุด จะได้เริ่มพูดเร็ว)"""
    words, out, cur = text.split(" "), [], ""
    for w in words:
        limit = first if not out else size
        if cur and len(cur) + len(w) + 1 > limit:
            out.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        out.append(cur)
    return out


def _cached(text):
    """ประโยคสั้นที่ใช้บ่อย (เช่น "ครับ", "ไว้คุยกันใหม่นะครับ") เก็บไฟล์ไว้ใช้ซ้ำ ไม่ต้องสร้างใหม่"""
    import hashlib
    d = os.path.join(config.DATA_DIR, "tts_cache")
    os.makedirs(d, exist_ok=True)
    key = f"{config.TTS_ENGINE}|{config.TTS_VOICE}|{config.GEMINI_TTS_VOICE}|{config.TTS_RATE}|{config.TTS_PITCH}|{text}"
    path = os.path.join(d, hashlib.md5(key.encode()).hexdigest() + ".mp3")
    if not os.path.exists(path):
        synthesize(text, path)
    return path


def say(text, wait=True):
    """พูดข้อความออกลำโพงของเครื่อง: สร้างเสียงท่อนถัดไปไปพร้อมกับเล่นท่อนปัจจุบัน → เริ่มพูดเร็วขึ้น"""
    if not wait:
        import threading
        threading.Thread(target=say, args=(text, True), daemon=True).start()
        return None
    text = clean_for_speech(text)
    if not text:
        return None
    if len(text) <= 40:
        play(_cached(text))
        return None
    from concurrent.futures import ThreadPoolExecutor
    parts = _chunks(text)
    started = time.time()
    with ThreadPoolExecutor(max_workers=3) as ex:
        futures = [ex.submit(synthesize, p) for p in parts]
        for fut in futures:
            path = fut.result()
            try:
                if _current.get("cancel_at", 0) >= started:   # ถูกสั่งหยุด (ผู้ใช้พูดแทรก)
                    continue
                play(path)
            finally:
                _remove(path)
    return None


class Speaker:
    """รับข้อความทีละนิด (จาก AI ที่กำลังพิมพ์) → ตัดเป็นท่อน → สร้างเสียงล่วงหน้า → พูดต่อกันทันที"""

    ENDS = (".", "!", "?", "\n", "ครับ ", "ค่ะ ", "นะ ", "คะ ")

    def __init__(self, max_chars=0):
        import queue
        from concurrent.futures import ThreadPoolExecutor
        self.max_chars = max_chars      # พูดแค่ช่วงแรก ที่เหลือดูใน Telegram (0 = พูดทั้งหมด)
        self.chars = 0
        self.truncated = False
        self.buf = ""
        self.count = 0
        self.spoken = []
        self.stopped = False
        self.pool = ThreadPoolExecutor(max_workers=3)
        self.q = queue.Queue()
        self.t = threading.Thread(target=self._player, daemon=True)
        self.t.start()

    def feed(self, delta):
        self.buf += delta
        while True:
            limit = 35 if self.count == 0 else 100
            cut = -1
            for e in self.ENDS:
                i = self.buf.find(e)
                if i >= 0 and (cut < 0 or i < cut):
                    cut = i + len(e)
            if cut < 0 and len(self.buf) > limit:
                sp = self.buf.rfind(" ", 0, limit + 20)
                cut = sp + 1 if sp > 10 else -1
            if cut <= 0:
                break
            self._emit(self.buf[:cut])
            self.buf = self.buf[cut:]

    def busy(self):
        """ยังมีเสียงรอพูดหรือกำลังพูดอยู่"""
        return self.t.is_alive() and not self.stopped

    def stop(self):
        """ผู้ใช้พูดแทรก: หยุดพูดทันที ทิ้งประโยคที่เหลือ"""
        self.stopped = True
        while not self.q.empty():
            try:
                self.q.get_nowait()
            except Exception:  # noqa: BLE001
                break
        self.q.put(None)
        stop_playing()

    def _emit(self, text):
        if self.stopped or self.truncated:
            return
        text = clean_for_speech(text)
        if len(text) < 2:
            return
        if self.max_chars and self.chars >= self.max_chars:
            self.truncated = True
            text = "รายละเอียดเพิ่มเติมส่งเข้า Telegram แล้วครับ"
        self.chars += len(text)
        self.count += 1
        self.spoken.append(text)
        fut = self.pool.submit(_cached if len(text) <= 12 else synthesize, text)
        self.q.put((fut, len(text) > 12))

    def _player(self):
        while True:
            item = self.q.get()
            if item is None:
                return
            fut, temp = item
            if self.stopped:
                continue
            try:
                path = fut.result()
                if not self.stopped:
                    play(path)
                if temp:
                    _remove(path)
            except Exception:  # noqa: BLE001
                pass

    def close(self):
        """ส่งท่อนสุดท้ายเข้าคิว (ไม่รอให้พูดจบ)"""
        self._emit(self.buf)
        self.buf = ""
        self.q.put(None)

    def finish(self):
        """พูดส่วนที่เหลือ แล้วรอจนพูดจบ"""
        self.close()
        self.t.join(timeout=300)
        self.pool.shutdown(wait=False)


def normalize_pcm(pcm, target_peak=22000, max_gain=None):
    """ขยายเสียงที่เบาให้ดังพอ (ไมค์ MatePad ผ่าน PulseAudio ได้เสียงเบามาก ทำให้ฟังผิดบ่อย)
    คืน (pcm ใหม่, gain ที่ใช้, peak เดิม)"""
    import array
    a = array.array("h", pcm)
    if not a:
        return pcm, 1.0, 0
    # ใช้ค่าสูงช่วง 99.5% แทนค่าสูงสุด (กันเสียงกระแทกครั้งเดียวทำให้ขยายไม่ได้)
    srt = sorted(abs(x) for x in a[::4])
    peak = srt[int(len(srt) * 0.995)] if srt else 0
    if peak < 1:
        return pcm, 1.0, peak
    if max_gain is None:                       # ไมค์ของแอป (AudioRecord) ดังพอแล้ว → ขยายน้อย กันขยายเสียงรบกวนจนถอดผิด
        max_gain = 6.0 if config.ANDROID_APP else 50.0
    gain = min(max_gain, target_peak / peak)
    if gain <= 1.1:
        return pcm, 1.0, peak
    out = array.array("h", (max(-32767, min(32767, int(x * gain))) for x in a))
    return out.tobytes(), gain, peak


def highpass(pcm, cutoff=120):
    """ตัดเสียงทุ้มต่ำ (เสียงพัดลม/แอร์/เคาะโต๊ะ) ให้เสียงพูดชัดขึ้น"""
    import array
    import math
    a = array.array("h", pcm)
    if not a:
        return pcm
    rc = 1.0 / (2 * math.pi * cutoff)
    dt = 1.0 / 16000
    k = rc / (rc + dt)
    out = array.array("h", bytes(len(pcm)))
    py = px = 0.0
    for i, x in enumerate(a):
        y = k * (py + x - px)
        px, py = x, y
        out[i] = max(-32767, min(32767, int(y)))
    return out.tobytes()


def _vocab():
    """คำเฉพาะช่วยถอดเสียง: ค่าตั้งต้น + ชื่อคน/ห้องแชทที่บอทเคยเห็น (จำเองจากการใช้งาน)"""
    try:
        import skills
        names = skills.vocab()
    except Exception:  # noqa: BLE001
        names = ""
    return ", ".join(x for x in (config.STT_VOCAB, names) if x)


def _stt_prompt():
    try:
        import skills
        names = skills.vocab(150)
    except Exception:  # noqa: BLE001
        names = ""
    return f"{config.STT_PROMPT} {names}".strip()


def use_gemini_stt():
    return config.STT_ENGINE in ("gemini", "auto") and bool(config.GEMINI_API_KEY) and not config.MOCK_PHONE


# คำที่บอกว่าผู้ใช้กำลัง "บอกข้อความ" ให้พิมพ์/ส่ง → ต้องถอดให้ตรงทุกคำ
_DICTATION = re.compile(r"(พิมพ์|บอก|ตอบ|ส่ง|เขียน|โพสต์|คอมเมนต์|คอมเม้น|แคปชั่น|แคปชัน|ข้อความ|แชท|แชต|"
                        r"ไลน์|line|ig|อินสตา|เฟส|messenger|caption|comment|type)", re.I)


def needs_accurate(text):
    """ข้อความนี้ควรถอดซ้ำแบบแม่น (Gemini) ไหม"""
    if config.STT_ENGINE == "gemini":
        return True
    if config.STT_ENGINE != "auto" or not text:
        return False
    return bool(_DICTATION.search(text)) or bool(re.search(r"[A-Za-z]{3,}", text))


def transcribe_accurate(path_or_wav, mime="audio/wav"):
    """ถอดเสียงแบบแม่น (Gemini) ถ้าใช้ไม่ได้ค่อยใช้ Groq"""
    if use_gemini_stt() and time.time() > _last.get("gem_stt_off", 0):
        try:
            import gemini_client
            data = path_or_wav
            if isinstance(path_or_wav, str):
                with open(path_or_wav, "rb") as f:
                    data = f.read()
            t0 = time.time()
            text = fix_mojibake(gemini_client.transcribe(data, mime=mime, vocab=_vocab()))
            _last["engine"], _last["stt_time"] = "Gemini", time.time() - t0
            return text
        except Exception as e:  # noqa: BLE001
            _last["gem_stt_off"] = time.time() + 3600      # พักใช้ Gemini 1 ชม. ไม่ให้ทุกประโยคเสียเวลาลองซ้ำ
            print(f"⚠️ ถอดเสียงด้วย Gemini ไม่ได้ → ใช้ Groq (พัก Gemini 1 ชม.): {str(e)[:120]}", flush=True)
    if isinstance(path_or_wav, str):
        _last["engine"] = "Groq"
        return transcribe(path_or_wav)
    raise VoiceError("ไม่มีไฟล์เสียง")


def transcribe_pcm(pcm, accurate=False):
    """accurate=True: ใช้ Gemini (แม่นกับไทยปนอังกฤษ/ชื่อเฉพาะ ช้ากว่า ~1 วินาที) / False: Groq (เร็ว)"""
    import audio_stream
    pcm = highpass(pcm)
    pcm, gain, peak = normalize_pcm(pcm)
    _last["gain"], _last["peak"] = gain, peak
    path = os.path.join(config.DATA_DIR, "utterance.wav")
    audio_stream.write_wav(pcm, path)
    t0 = time.time()
    _last["engine"] = "Groq"
    text = transcribe(path)                       # เร็ว (~0.5 วิ)
    if accurate and use_gemini_stt() and needs_accurate(text):
        better = transcribe_accurate(path)        # แม่น (เฉพาะตอนบอกข้อความให้พิมพ์/ส่ง)
        if better:
            _last["engine"] = "Groq+Gemini"
            text = better
    _last["stt_time"] = time.time() - t0
    return text


_last = {"gain": 1.0, "peak": 0, "engine": "Groq", "stt_time": 0.0}


def beep(freq=880, ms=150):
    """เสียงติ๊ดบอกว่า "เริ่มฟังแล้ว" (แท็บเล็ตไม่มีระบบสั่น)"""
    path = os.path.join(config.DATA_DIR, f"beep_{freq}.wav")
    if not os.path.exists(path):
        rate = 16000
        n = int(rate * ms / 1000)
        with wave.open(path, "w") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(rate)
            fade = max(1, n // 10)
            frames = b"".join(
                struct.pack("<h", int(12000 * min(1, i / fade, (n - i) / fade) *
                                      math.sin(2 * math.pi * freq * i / rate)))
                for i in range(n))
            w.writeframes(frames)
    try:
        play(path)
    except Exception:  # noqa: BLE001
        pass


# ---------------------------------------------------------------- อัดเสียง

def record(seconds, path=None):
    """อัดเสียงจากไมค์ของเครื่อง คืน path ของไฟล์ m4a"""
    path = path or os.path.join(config.DATA_DIR, "listen.m4a")
    if config.MOCK_PHONE:
        with open(path, "wb") as f:
            f.write(b"mock")
        return path
    _remove(path)
    out = _api(["termux-microphone-record", "-f", path, "-l", str(int(seconds))],
                         capture_output=True, text=True, timeout=20).stdout
    if "error" in out.lower():
        raise VoiceError(f"อัดเสียงไม่ได้: {out.strip()} (ให้สิทธิ์ไมโครโฟนกับ Termux:API)")
    time.sleep(seconds + 0.3)
    _api(["termux-microphone-record", "-q"])
    # รอให้เขียนไฟล์เสร็จ
    last = -1
    for _ in range(20):
        size = os.path.getsize(path) if os.path.exists(path) else 0
        if size and size == last:
            break
        last = size
        time.sleep(0.25)
    if not os.path.exists(path) or os.path.getsize(path) < 500:
        raise VoiceError("ไฟล์เสียงว่างเปล่า ไมค์อาจถูกบล็อกตอนปิดจอ")
    return path


def loudness_db(path):
    """ความดังสูงสุดของไฟล์ (dB) ใช้ ffmpeg ถ้ามี — คืน None ถ้าตรวจไม่ได้"""
    if config.MOCK_PHONE or not shutil.which("ffmpeg"):
        return None
    out = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-af", "volumedetect",
                          "-f", "null", "-"], capture_output=True, text=True, timeout=30).stderr
    m = re.search(r"max_volume:\s*(-?[\d.]+) dB", out)
    return float(m.group(1)) if m else None


def _remove(path):
    try:
        os.remove(path)
    except OSError:
        pass
