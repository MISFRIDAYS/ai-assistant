"""ทดสอบรุ่นสำหรับผู้ทดลอง: บังคับลงทะเบียนเสียง + รองรับมือถือหลายยี่ห้อ"""
import os
import sys
import tempfile
import unittest
from unittest import mock

os.environ.update({"MOCK_PHONE": "1", "ANTHROPIC_API_KEY": "test", "TELEGRAM_BOT_TOKEN": "test",
                   "ALLOWED_USER_IDS": "111"})
os.environ.setdefault("SHARED_STORAGE", tempfile.mkdtemp())
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config  # noqa: E402


class TestVoiceEnrollGate(unittest.TestCase):
    def setUp(self):
        import voice_chat
        self.vc = voice_chat
        voice_chat._ENROLLING[0] = False

    def test_blocks_until_enrolled(self):
        import speaker_id
        with mock.patch.object(config, "REQUIRE_VOICE_ENROLL", True, create=True), \
                mock.patch.object(speaker_id, "enrolled", return_value=False):
            self.assertFalse(self.vc.owner_voice(b"\0" * 32000))

    def test_passes_after_enrolled(self):
        import speaker_id
        with mock.patch.object(config, "REQUIRE_VOICE_ENROLL", True, create=True), \
                mock.patch.object(config, "SPEAKER_VERIFY", True), \
                mock.patch.object(speaker_id, "enrolled", return_value=True), \
                mock.patch.object(speaker_id, "check", return_value=(True, 0.9)):
            self.assertTrue(self.vc.owner_voice(b"\0" * 32000))

    def test_not_required_keeps_old_behaviour(self):
        import speaker_id
        with mock.patch.object(config, "REQUIRE_VOICE_ENROLL", False, create=True), \
                mock.patch.object(config, "SPEAKER_VERIFY", False), \
                mock.patch.object(speaker_id, "enrolled", return_value=False):
            self.assertTrue(self.vc.owner_voice(b"\0" * 32000))

    def test_off_outside_android_app(self):
        self.assertFalse(config.REQUIRE_VOICE_ENROLL)       # Termux/คอม/เทสต์ ไม่บังคับ


class TestOtherBrands(unittest.TestCase):
    def tearDown(self):
        import device
        device._DEV.clear()

    def test_brand_packages_listed(self):
        import phone_tools
        alt = phone_tools.ALT_PKGS
        self.assertIn("com.sec.android.app.camera", alt["camera"])          # Samsung
        self.assertIn("com.miui.gallery", alt["gallery"])                   # Xiaomi/Redmi
        self.assertIn("com.bbk.calendar", alt["calendar"])                  # Vivo
        self.assertIn("com.coloros.calculator", alt["calculator"])          # Oppo
        self.assertIn("com.samsung.android.app.notes", alt["notes"])
        self.assertIn("files", alt)

    def _as(self, man, model="Phone", ver="14"):
        import device
        device._DEV.clear()
        device._DEV["id"] = (man, model, ver)
        return device

    def test_other_brand_gets_generic_knowledge(self):
        d = self._as("samsung", "SM-A556E")
        self.assertFalse(d.is_matepad())
        self.assertNotIn("AppGallery", d.prompt())
        self.assertIn("SM-A556E", d.prompt())

    def test_huawei_keeps_matepad_knowledge(self):
        d = self._as("HUAWEI", "TXZ-W09")
        self.assertTrue(d.is_matepad())
        self.assertIn("AppGallery", d.prompt())

    def test_info_names_real_phone(self):
        d = self._as("Xiaomi", "Redmi Note 13", "14")
        with mock.patch.object(d, "live", return_value={}):
            out = d.info()
        self.assertIn("Redmi Note 13", out)
        self.assertNotIn("MatePad", out)


if __name__ == "__main__":
    unittest.main()
