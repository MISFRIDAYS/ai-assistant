"""รู้จักปุ่มทุกปุ่ม + งานสำเร็จรูปในแอปที่ใช้บ่อย

1) เรียนรู้ไอคอนไม่มีชื่อ (เช่นปุ่ม + สีแดงของ WPS / ปุ่มเขียนโน้ต) — ถ่ายจอ วาดกรอบเลข ให้ AI ที่ดูรูปได้บอกว่าแต่ละปุ่มคืออะไร
   เก็บไว้ต่อแอป → read_screen/tap_text เห็นชื่อปุ่มที่เรียนรู้ไว้ (เช่น ≈"สร้างไฟล์ใหม่")
2) งานสำเร็จรูป (กดตามขั้น + ถ้าหาไม่เจอใช้ตำแหน่งปุ่มลอย/มองภาพ):
   "สร้างเอกสารใหม่ใน wps" · "สร้างเอกสาร wps เรื่อง ประชุมทีม" · "จดโน้ตว่า ซื้อนม" · "สร้างโน้ตใหม่"
"""
import json
import os
import re
import time

import config

_DANGER = re.compile(r"ลบ|delete|remove|จ่าย|ชำระ|pay|ซื้อ|buy|ส่ง|send|โทร|call|ออกจากระบบ|log ?out|sign ?out|"
                     r"รีเซ็ต|reset|ถอน|uninstall|โอน|transfer|สั่งซื้อ|order", re.I)
_CREATE = re.compile(r"^(\+|＋|สร้าง|ใหม่|เพิ่ม|New|Create|Add|เขียน|Compose)$|fab|floating|new_?(file|note|doc)|add_?(note|file|btn)|"
                     r"create|compose|btn_?add|plus", re.I)


def _b():
    import android_shim
    return android_shim.bridge()


def _items():
    import share_tools
    return share_tools._items()


def _lab(e):
    return (e.get("text") or e.get("desc") or "").strip()


def _size(items):
    w = max((e["box"][2] for e in items), default=1080)
    h = max((e["box"][3] for e in items), default=2000)
    return w, h


# ================================================================ เรียนรู้ไอคอนไม่มีชื่อ

def _store():
    import skills
    return skills


def icons_for(pkg):
    return (_store().get_pref(f"icons:{pkg}") or {}).get("icons", [])


def unlabeled(items):
    w, h = _size(items)
    out = []
    for e in items:
        bw, bh = e["box"][2] - e["box"][0], e["box"][3] - e["box"][1]
        if e.get("click") and not e.get("edit") and not _lab(e) and 20 < bw < w * 0.35 and 20 < bh < h * 0.2:
            out.append(e)
    return out[:20]


def learn_icons(pkg, items=None):
    """ถ่ายจอ → ให้ AI บอกชื่อไอคอนที่ไม่มีชื่อ → จำไว้ (คืนจำนวนที่เรียนรู้ได้)"""
    if not config.ANDROID_APP:
        return 0
    items = items if items is not None else _items()
    targets = unlabeled(items)
    if not targets:
        return 0
    w, h = _size(items)
    shot = os.path.join(config.DATA_DIR, "icons_raw.png")
    ann = os.path.join(config.DATA_DIR, "icons_ann.jpg")
    b = _b()
    if not b.screenshot(shot) or not b.annotate(shot, json.dumps([list(e["box"]) for e in targets]), ann):
        return 0
    import vision
    try:
        ans = vision.ask_images(
            "ภาพหน้าจอแอปที่มีกรอบแดงพร้อมเลข แต่ละกรอบคือปุ่มที่ไม่มีชื่อ บอกว่าปุ่มแต่ละเลขน่าจะทำอะไร "
            "เป็นภาษาไทยสั้นๆ 2-5 คำ (เช่น \"สร้างไฟล์ใหม่\", \"ค้นหา\", \"เมนู\", \"ย้อนกลับ\", \"แชร์\") "
            'ตอบ JSON เท่านั้น: {"1": "...", "2": "..."} ถ้าไม่แน่ใจใส่ "?"', [ann])
    except Exception as e:  # noqa: BLE001
        print(f"[icons] {e}", flush=True)
        return 0
    if not ans:
        return 0
    m = re.search(r"\{.*\}", ans, re.S)
    try:
        labels = json.loads(m.group(0)) if m else {}
    except ValueError:
        return 0
    known = {(round(i["x"], 2), round(i["y"], 2)): i for i in icons_for(pkg)}
    n = 0
    for i, e in enumerate(targets):
        lab = str(labels.get(str(i + 1), "")).strip()
        if not lab or lab == "?" or len(lab) > 30:
            continue
        rx, ry = round(e["x"] / w, 3), round(e["y"] / h, 3)
        known[(round(rx, 2), round(ry, 2))] = {"x": rx, "y": ry, "label": lab, "id": e.get("id", "")}
        n += 1
    _store().set_pref(f"icons:{pkg}", {"icons": list(known.values())[-60:], "at": time.strftime("%Y-%m-%d")})
    return n


def label_of(pkg, e, w, h):
    """ชื่อที่เรียนรู้ไว้ของไอคอนนี้ (เทียบตำแหน่งบนจอ หรือ id)"""
    for i in icons_for(pkg):
        if (i.get("id") and i["id"] == e.get("id")) or \
                (abs(i["x"] - e["x"] / w) < 0.035 and abs(i["y"] - e["y"] / h) < 0.03):
            return i["label"]
    return ""


def find_learned(pkg, query, items):
    """tap_text หาไม่เจอ → ลองหาจากชื่อไอคอนที่เรียนรู้ไว้"""
    w, h = _size(items)
    q = query.strip().lower()
    for e in unlabeled(items):
        lab = label_of(pkg, e, w, h).lower()
        if lab and (q in lab or lab in q):
            return e
    return None


# ================================================================ งานสำเร็จรูป

def _fab(items):
    """ปุ่มลอยมุมขวาล่าง (มักเป็น "สร้างใหม่") ที่ไม่มีชื่อ"""
    w, h = _size(items)
    c = [e for e in unlabeled(items) if e["x"] > w * 0.6 and h * 0.6 < e["y"] < h * 0.95
         and abs((e["box"][2] - e["box"][0]) - (e["box"][3] - e["box"][1])) < 60]
    return max(c, key=lambda e: e["y"]) if c else None


def _find(items, rx):
    r = re.compile(rx, re.I)
    hits = [e for e in items if not e.get("edit") and (r.search(_lab(e)) or r.search(e.get("id") or ""))
            and not _DANGER.search(_lab(e))]
    hits.sort(key=lambda e: (not e.get("click"), len(_lab(e))))
    return hits[0] if hits else None


def _tap(e):
    import screen_tools
    screen_tools.adb_shell(["input", "tap", str(e["x"]), str(e["y"])])


_POPUP = r"^(ข้าม|Skip|ภายหลัง|Later|ไว้ทีหลัง|ไม่ใช่ตอนนี้|Not now|ปิด|Close|ยอมรับ|Agree|ตกลง|OK|Got it|เข้าใจแล้ว|×|✕)$"


def _dismiss(tries=2):
    for _ in range(tries):
        try:
            e = _find(_items(), _POPUP)
        except RuntimeError:
            return
        if not e:
            return
        _tap(e)
        time.sleep(0.8)


def step(rx=None, visual=None, fab=False, optional=False, wait=1.4, pkg=""):
    """แตะปุ่มหนึ่งขั้น: ชื่อ/ id ตรง rx → ไอคอนที่เรียนรู้ไว้ → ปุ่มลอย → มองภาพ"""
    items = _items()
    e = _find(items, rx) if rx else None
    if not e and visual and pkg:
        e = find_learned(pkg, visual, items)
    if not e and fab:
        e = _fab(items)
    if not e and visual:
        import screen_tools
        e = screen_tools.vision_find(visual)
    if not e:
        if optional:
            return True, ""
        return False, f"หา \"{visual or rx}\" ไม่เจอ"
    _tap(e)
    time.sleep(wait)
    return True, _lab(e) or visual or "ปุ่ม"


def step_home(rx, visual, pkg, fab=True):
    """หาปุ่มแรกของงาน — ไม่เจอ (ค้างหน้าอื่น/เปิดเอกสารค้างไว้) → ย้อนกลับทีละหน้าแล้วลองใหม่ (สูงสุด 3 ครั้ง)"""
    import phone_tools
    import screen_tools
    ok, what = step(rx, visual, fab=fab, pkg=pkg)
    tries = 0
    while not ok and tries < 3:
        tries += 1
        screen_tools.adb_shell(["input", "keyevent", "4"])
        time.sleep(1.0)
        if pkg and phone_tools._fg() not in (pkg, None):          # ย้อนจนหลุดแอป → เปิดใหม่ที่หน้าแรก
            phone_tools.open_app({"app": pkg, "fresh": True}, None)
            time.sleep(2.0)
        _dismiss(1)
        ok, what = step(rx, visual, fab=fab, pkg=pkg)
    return ok, what


def _open(names, ctx):
    import app_index
    import phone_tools
    for n in names:
        pkg, _lab2 = app_index.find(n)
        if pkg and "." in pkg:
            r = phone_tools.open_app({"app": pkg, "fresh": True}, ctx)
            if not r.startswith("ERROR"):
                time.sleep(2.5)
                return pkg
    return None


def _type(text, ctx):
    import screen_tools
    return screen_tools.type_text({"text": text}, ctx)


def wps_new_doc(body="", ctx=None):
    pkg = _open(["WPS Office", "wps", "cn.wps.moffice_eng", "com.kingsoft.moffice_pro"], ctx)
    if not pkg:
        return "ERROR: ไม่พบแอป WPS Office ในเครื่อง"
    _dismiss()
    trail = []
    ok, what = step_home(_CREATE.pattern, "ปุ่มสร้างไฟล์ใหม่ (เครื่องหมาย + สีแดงมุมขวาล่าง)", pkg)
    if not ok:
        return f"เปิด WPS แล้วแต่ {what} — สอนให้ดูครั้งเดียวได้: สั่ง \"จำขั้นตอน สร้างเอกสาร wps\" แล้วกดเอง"
    trail.append(what)
    ok, what = step(r"^(เอกสาร|Document|Documents|Doc|Docs|Writer|Word|เวิร์ด)$", "ปุ่ม เอกสาร/Document", pkg=pkg)
    if not ok:
        return f"กด {trail[-1]} แล้ว แต่ {what}"
    trail.append(what)
    ok, what = step(r"^(ว่าง|เปล่า|เอกสารเปล่า|เอกสารว่าง|Blank|New Blank|Blank document|สร้างเอกสารเปล่า|\+ ?ว่าง)$",
                    "แม่แบบเอกสารว่าง (Blank)", optional=True, wait=2.5, pkg=pkg)
    if what:
        trail.append(what)
    if body:
        items = _items()
        if not any(e.get("edit") for e in items):
            step(r"^(แก้ไข|Edit)$", None, optional=True, wait=1.2)
            w, h = _size(_items())
            import screen_tools
            screen_tools.adb_shell(["input", "tap", str(w // 2), str(int(h * 0.35))])
            time.sleep(0.8)
        r = _type(body, ctx)
        trail.append("พิมพ์เนื้อหา" if not r.startswith("ERROR") else f"พิมพ์ไม่ได้ ({r[:60]})")
    return "📄 สร้างเอกสารใหม่ใน WPS แล้ว (" + " → ".join(trail) + ")"


def note_new(body="", ctx=None):
    pkg = _open(["บันทึก", "Notepad", "Notes", "โน้ต", "com.example.android.notepad", "com.huawei.notepad",
                 "Google Keep", "com.google.android.keep"], ctx)
    if not pkg:
        return "ERROR: ไม่พบแอปโน้ตในเครื่อง"
    _dismiss()
    ok, what = step_home(_CREATE.pattern + r"|^(บันทึกใหม่|โน้ตใหม่|New note|สร้างบันทึก|เขียนบันทึก)$",
                         "ปุ่มสร้างบันทึกใหม่ (+ หรือรูปดินสอ)", pkg)
    if not ok:
        return f"เปิดแอปโน้ตแล้วแต่ {what} — สอนให้ดูได้: สั่ง \"จำขั้นตอน สร้างโน้ต\" แล้วกดเอง"
    trail = [what]
    step(r"^(บันทึก|Note|Notes|โน้ต|ข้อความ|Text)$", None, optional=True, wait=1.2)
    if body:
        r = _type(body, ctx)
        trail.append("พิมพ์แล้ว" if not r.startswith("ERROR") else f"พิมพ์ไม่ได้ ({r[:60]})")
        ok2, w2 = step(r"^(✓|✔|เสร็จ|เสร็จสิ้น|Done|บันทึก|Save)$|done|save|confirm|ok_btn", None, optional=True, wait=1.0)
        if w2:
            trail.append(w2)
        else:
            import screen_tools
            screen_tools.adb_shell(["input", "keyevent", "4"])       # ย้อนกลับ = บันทึกอัตโนมัติ (แอปโน้ตส่วนใหญ่)
            trail.append("ย้อนกลับเพื่อบันทึก")
    return "📝 สร้างโน้ตใหม่แล้ว (" + " → ".join(trail) + ")"


def _write(topic, kind):
    """ให้ AI เขียนเนื้อหาตามเรื่อง"""
    import agent
    import polite
    resp, _ = agent.call_llm([{"role": "user", "content": [{"type": "text", "text":
                              f"เขียน{kind}เรื่อง: {topic}\nภาษาไทย กระชับ เป็นธรรมชาติ ไม่มี markdown ไม่มีคำนำ"}]}], [],
                             system=agent.chat_prompt())
    return polite.fix(agent._collect_text(resp.get("content", [])).strip())


_WPS = re.compile(r"^(?:ช่วย)?\s*(?:เปิด\s*(?:wps|ดับบลิวพีเอส)\s*(?:แล้ว)?\s*)?สร้าง\s*(?:ไฟล์)?\s*(?:เอกสาร|word|เวิร์ด)\s*(?:ใหม่)?"
                  r"\s*(?:ใน|ด้วย|ที่)?\s*(?:แอป)?\s*(?:wps|ดับบลิวพีเอส)?(?:\s*office)?\s*"
                  r"(?:(?P<v>ว่า|เขียนว่า|พิมพ์ว่า)\s*(?P<t>.+)|(?:เรื่อง|หัวข้อ)\s*(?P<topic>.+))?$", re.I)
_NOTE = re.compile(r"^(?:ช่วย)?\s*(?:จด|สร้าง|เขียน|เพิ่ม)\s*(?:โน้ต|โน๊ต|บันทึก|memo|note)\s*(?:ใหม่)?\s*(?:ไว้)?"
                   r"\s*(?:(?:ว่า|:)\s*(?P<t>.+)|(?:เรื่อง)\s*(?P<topic>.+))?$", re.I)


def handle_text(text, ctx=None):
    t = " ".join(re.sub(r"\[[^\]]*\]", " ", text or "").split()).strip()
    t = re.sub(r"\s*(ให้หน่อย|หน่อย|ครับ|ค่ะ|นะ|ที)+\s*$", "", t)
    if not t or not config.ANDROID_APP:
        return None
    m = _WPS.match(t)
    if m and ("wps" in t.lower() or "ดับบลิวพีเอส" in t or "เอกสาร" in t):
        body = (m.group("t") or "").strip() or (_write(m.group("topic"), "เอกสาร") if m.group("topic") else "")
        return wps_new_doc(body, ctx)
    m = _NOTE.match(t)
    if m:
        body = (m.group("t") or "").strip() or (_write(m.group("topic"), "บันทึกสั้นๆ") if m.group("topic") else "")
        return note_new(body, ctx)
    return None


def _obj(props, req):
    return {"type": "object", "properties": props, "required": req}


TOOLS = {
    "wps_new_document": (lambda a, ctx: wps_new_doc(a.get("text", ""), ctx),
                         "สร้างเอกสารใหม่ใน WPS Office (+ พิมพ์เนื้อหาให้ถ้าใส่ text)",
                         _obj({"text": {"type": "string"}}, []), False),
    "new_note": (lambda a, ctx: note_new(a.get("text", ""), ctx), "สร้างโน้ต/บันทึกใหม่ในแอปบันทึก (+ เนื้อหา)",
                 _obj({"text": {"type": "string"}}, []), False),
}
