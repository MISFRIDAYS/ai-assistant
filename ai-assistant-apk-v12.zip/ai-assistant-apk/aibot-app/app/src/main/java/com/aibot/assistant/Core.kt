package com.aibot.assistant

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

class App : Application() {
    companion object {
        const val CH_RUN = "run"
        const val CH_ASK = "ask"
        const val CH_INFO = "info"
        @Volatile var top: android.app.Activity? = null

        /** เริ่ม Python (ครั้งเดียวต่อโปรเซส) */
        fun py(ctx: Context): Python {
            if (!Python.isStarted()) Python.start(AndroidPlatform(ctx.applicationContext))
            return Python.getInstance()
        }
    }

    override fun onCreate() {
        super.onCreate()
        Bridge.app = this
        // จำว่าหน้าจอไหนของแอปเปิดอยู่ (ไว้ถอยแอปไปเบื้องหลังก่อนสั่งงานบนจอ)
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityResumed(a: android.app.Activity) { top = a }
            override fun onActivityPaused(a: android.app.Activity) { if (top === a) top = null }
            override fun onActivityCreated(a: android.app.Activity, b: android.os.Bundle?) {}
            override fun onActivityStarted(a: android.app.Activity) {}
            override fun onActivityStopped(a: android.app.Activity) {}
            override fun onActivitySaveInstanceState(a: android.app.Activity, b: android.os.Bundle) {}
            override fun onActivityDestroyed(a: android.app.Activity) {}
        })
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "ผู้ช่วยทำงานอยู่", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ASK, "ขออนุญาต / คำถาม", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_INFO, "ข้อความจากผู้ช่วย", NotificationManager.IMPORTANCE_DEFAULT))
    }
}

/** ข้อความในหน้าแชทของแอป (เก็บล่าสุด 300 ข้อความ) + คำถาม/ขออนุญาตที่รอตอบ */
object ChatLog {
    data class Msg(val role: String, val text: String, val time: Long = System.currentTimeMillis())
    data class Prompt(val id: Int, val kind: String, val text: String)

    val items = CopyOnWriteArrayList<Msg>()
    val prompts = CopyOnWriteArrayList<Prompt>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun listen(l: () -> Unit) = listeners.add(l)
    fun unlisten(l: () -> Unit) = listeners.remove(l)
    private fun fire() = main.post { listeners.forEach { it() } }

    fun add(role: String, text: String) {
        // ข้อความสถานะซ้อนกันได้แค่อันเดียว (ไม่รกหน้าจอ)
        if (role == "status" && items.isNotEmpty() && items.last().role == "status") items.removeAt(items.size - 1)
        items.add(Msg(role, text))
        while (items.size > 300) items.removeAt(0)
        fire()
    }

    fun prompt(id: Int, kind: String, text: String) { prompts.add(Prompt(id, kind, text)); fire() }

    // สถานะผู้ช่วยเสียง (กำลังฟัง/คิด/ตอบ) → แสดงบนหัวหน้าแชท
    @Volatile var moodTitle = ""
    @Volatile var moodText = ""
    fun setMood(title: String, text: String, ongoing: Boolean) { moodTitle = title; moodText = text; fire() }
    fun clearPrompt(id: Int) { prompts.removeIf { it.id == id }; fire() }
}

/** ปุ่ม "อนุญาต/ยกเลิก" และช่องตอบในแจ้งเตือน */
class ActionReceiver : BroadcastReceiver() {
    companion object {
        const val CONFIRM = "com.aibot.assistant.CONFIRM"
        const val ASK = "com.aibot.assistant.ASK"
        const val KEY_TEXT = "text"
        const val PAUSE = "com.aibot.assistant.PAUSE"
        const val STOP_RECORD = "com.aibot.assistant.STOP_RECORD"
    }

    override fun onReceive(ctx: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        when (i.action) {
            CONFIRM -> Bridge.answer(id, i.getBooleanExtra("ok", false), null)
            PAUSE -> Bridge.setEnabled(false)
            STOP_RECORD -> Thread {
                try {
                    val r = App.py(ctx).getModule("android_main").callAttr("tool", "record_stop", "").toString()
                    ChatLog.add("bot", r)
                    Bridge.postNotif(42, "ผู้ช่วย AI", r)
                } catch (e: Throwable) { Bridge.log("record_stop: $e") }
            }.start()
            ASK -> {
                val txt = RemoteInput.getResultsFromIntent(i)?.getCharSequence(KEY_TEXT)?.toString()
                Bridge.answer(id, txt != null, txt)
            }
        }
    }
}

/** บริการหลัก: รันสมองบอท (Python) ตลอด — Telegram, ผู้ช่วยเสียง, ตรวจซ่อมตัวเอง */
class BotService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var started = false

        fun start(ctx: Context) {
            if (!ctx.getSharedPreferences("app", Context.MODE_PRIVATE).getBoolean("enabled", true)) return
            val i = Intent(ctx, BotService::class.java)
            try { ctx.startForegroundService(i) } catch (e: Exception) { Bridge.log("start service: $e") }
        }
    }

    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, App.CH_RUN)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("🤖 ผู้ช่วยทำงานอยู่")
            .setContentText("สั่งผ่านแอป / Telegram / เสียง ได้เลย")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null as android.graphics.drawable.Icon?, "⏸️ ปิดผู้ช่วย",
                PendingIntent.getBroadcast(this, 4, Intent(this, ActionReceiver::class.java).setAction(ActionReceiver.PAUSE),
                    PendingIntent.FLAG_IMMUTABLE)).build())
            .addAction(Notification.Action.Builder(null as android.graphics.drawable.Icon?, "🎤 สั่งด้วยเสียง",
                PendingIntent.getActivity(this, 3, Intent(this, ListenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE)).build())
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                if (Bridge.micAllowed()) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (Bridge.camAllowed()) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                startForeground(1, n, type)
            } else if (Build.VERSION.SDK_INT >= 30) {
                var type = 0
                if (Bridge.micAllowed()) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (Bridge.camAllowed()) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                startForeground(1, n, type)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            Bridge.log("startForeground: $e")
            try {
                if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                else startForeground(1, n)
            } catch (e2: Exception) { Bridge.log("startForeground2: $e2") }
        }
        if (wake == null) {
            wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aibot:run").also { it.acquire() }
        }
        if (!started) {
            started = true
            Thread {
                try {
                    App.py(this).getModule("android_main").callAttr("start_bot")
                    running = true
                    Bridge.log("✅ สมองบอทเริ่มทำงาน")
                } catch (e: Throwable) {
                    Bridge.log("❗ เริ่มบอทไม่สำเร็จ: $e")
                    Bridge.post("status", "❗ เริ่มบอทไม่สำเร็จ: $e")
                }
            }.start()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { wake?.release() } catch (_: Exception) {}
        running = false
        super.onDestroy()
    }
}

/** โปรเซสแยกสำหรับรันเทสต์ตอนซ่อมตัวเอง (ไม่กวนบอทตัวจริง) */
class HealService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val stage = intent?.getStringExtra("stage") ?: return START_NOT_STICKY
        val result = intent?.getStringExtra("result") ?: return START_NOT_STICKY
        Thread {
            try {
                App.py(this).getModule("android_main").callAttr("run_tests", stage, result)
            } catch (e: Throwable) {
                try { File(result).writeText("{\"error\":\"${e.toString().replace("\"", "'").take(400)}\"}") } catch (_: Exception) {}
            }
            stopSelf()
            Process.killProcess(Process.myPid())      // ล้าง Python ของรอบเทสต์ทิ้งทั้งหมด
        }.start()
        return START_NOT_STICKY
    }
}

/** เปิดเครื่อง / อัปเดตแอป → เริ่มผู้ช่วยเอง */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val prefs = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)
        if (prefs.getBoolean("autostart", true) && prefs.getBoolean("enabled", true)) BotService.start(ctx)
    }
}
