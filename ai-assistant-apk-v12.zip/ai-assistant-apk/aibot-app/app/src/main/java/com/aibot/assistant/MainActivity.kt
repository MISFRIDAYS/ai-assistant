package com.aibot.assistant

import android.animation.Animator
import android.app.Activity
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** หน้าหลัก: แชทกับผู้ช่วย (ธีมม่วง-ขาว) + ไมค์ + ทางลัด + ป๊อปอัป */
class MainActivity : Activity() {
    companion object {
        @Volatile var visible = false
        @Volatile var current: MainActivity? = null
    }

    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var subtitle: TextView
    private lateinit var chips: LinearLayout
    private lateinit var input: EditText
    private lateinit var micBtn: TextView
    private lateinit var micHost: FrameLayout
    private lateinit var typing: LinearLayout
    private lateinit var typingText: TextView
    private lateinit var orb: TextView
    private lateinit var power: TextView
    private var micAnims: List<Animator> = emptyList()
    private val worker = Executors.newSingleThreadExecutor()
    private val busy = AtomicInteger(0)
    private val listener: () -> Unit = { render() }
    private val rendered = ArrayList<ChatLog.Msg>()
    private val dialogs = HashMap<Int, Dialog>()
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.US)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Ui.statusBar(this, Ui.P700)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.P50) }
        root.addView(buildHeader())
        root.addView(buildQuick())

        scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; isFillViewport = true }
        list = Ui.col(this, 14)
        scroll.addView(list)
        root.addView(scroll, Ui.lp(h = 0, weight = 1f))

        // กำลังคิด… (จุดเด้ง)
        typing = Ui.row(this).apply { visibility = View.GONE; setPadding(Ui.dp(this@MainActivity, 22), 0, 0, Ui.dp(this@MainActivity, 6)) }
        val (dots, _) = Fx.typingDots(this)
        typing.addView(dots)
        typingText = Ui.text(this, "กำลังคิด…", 13f, false, Ui.SUB).apply { setPadding(Ui.dp(this@MainActivity, 6), 0, 0, 0) }
        typing.addView(typingText)
        root.addView(typing)

        root.addView(buildInput())
        setContentView(root)

        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (!prefs.getBoolean("setup_seen", false)) {
            prefs.edit().putBoolean("setup_seen", true).apply()
            startActivity(Intent(this, SetupActivity::class.java))
        }
        BotService.start(this)
    }

    // ------------------------------------------------------------------ หัว
    private fun buildHeader(): View {
        val head = Ui.col(this, 0)
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Ui.P700, Ui.P500, Ui.PINK)).apply {
            val r = Ui.dpf(this@MainActivity, 30f)
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        }
        head.background = g
        Fx.shimmer(g, Ui.P700, Ui.P500, Ui.PINK)
        head.elevation = Ui.dpf(this, 6f)
        head.setPadding(Ui.dp(this, 18), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 16))

        val r = Ui.row(this)
        orb = TextView(this).apply {
            text = "🤖"; textSize = 26f; gravity = Gravity.CENTER
            background = Ui.oval(0x55FFFFFF, 0x22FFFFFF)
        }
        r.addView(orb, LinearLayout.LayoutParams(Ui.dp(this, 58), Ui.dp(this, 58)).apply { marginEnd = Ui.dp(this@MainActivity, 12) })
        Fx.breathe(orb, 1.07f, 1600)
        val tt = Ui.col(this, 0)
        tt.addView(Ui.text(this, "ผู้ช่วย AI", 23f, true, Color.WHITE))
        subtitle = Ui.text(this, "พร้อมรับคำสั่ง ✨", 13.5f, false, 0xE6FFFFFF.toInt()).apply { maxLines = 2 }
        tt.addView(subtitle)
        r.addView(tt, Ui.lp(0, weight = 1f))
        power = Ui.iconBtn(this, "⏻", 48) {
            val on = !Bridge.isEnabled()
            Bridge.setEnabled(on)
            Popups.snack(this, if (on) "▶️ เปิดผู้ช่วยแล้ว" else "⏸️ ปิดผู้ช่วยแล้ว (ไม่ฟังไมค์ ไม่ทำงานเบื้องหลัง)")
            refreshStatus()
        }.apply { setTextColor(Color.WHITE); textSize = 20f }
        r.addView(power)
        r.addView(Ui.iconBtn(this, "🧰") { startActivity(Intent(this, ToolsActivity::class.java)) })
        r.addView(Ui.iconBtn(this, "🔐") { startActivity(Intent(this, SetupActivity::class.java)) })
        r.addView(Ui.iconBtn(this, "⚙️") { startActivity(Intent(this, SettingsActivity::class.java)) })
        r.addView(Ui.iconBtn(this, "📄") { startActivity(Intent(this, LogActivity::class.java)) })
        head.addView(r)

        chips = Ui.row(this)
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) }
        head.addView(hs, Ui.lpm(this, t = 12))
        return head
    }

    private fun buildQuick(): View {
        val q = Ui.row(this)
        q.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 2))
        fun add(t: String, f: () -> Unit) = q.addView(Ui.chip(this, t, true, f), Ui.lpm(this, w = ViewGroup.LayoutParams.WRAP_CONTENT, e = 8))
        add("🩺 ตรวจซ่อม") { send("ตรวจซ่อม") }
        add("🔔 แจ้งเตือน") { send("มีแจ้งเตือนอะไรบ้าง") }
        add("🔋 แบต") { send("แบตเหลือเท่าไหร่") }
        add("▶️ YouTube") { send("เปิด youtube") }
        add("📝 กรอกฟอร์ม") { send("กรอกฟอร์ม") }
        add("📚 ศึกษาแอป…") { prefill("ศึกษาแอป ") }
        add("🎬 จำขั้นตอน…") { prefill("จำขั้นตอน ") }
        add("🔒 ข้อมูลของฉัน") { send("ข้อมูลของฉัน") }
        add("🛠️ ประวัติซ่อม") { send("ประวัติการซ่อม") }
        add("📋 ทำอะไรได้บ้าง") { help() }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(q) }
    }

    private fun buildInput(): View {
        val bar = Ui.row(this)
        bar.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 10), Ui.dp(this, 12))

        micHost = FrameLayout(this).apply { clipChildren = false; clipToPadding = false }
        micBtn = TextView(this).apply {
            text = "🎤"; textSize = 22f; gravity = Gravity.CENTER
            background = Ui.ripple(Ui.oval(Ui.P500, Ui.PINK), 0x55FFFFFF)
            elevation = Ui.dpf(this@MainActivity, 6f)
            setOnClickListener { Fx.press(this); listenOnce() }
        }
        micHost.addView(micBtn, FrameLayout.LayoutParams(Ui.dp(this, 54), Ui.dp(this, 54), Gravity.CENTER))
        bar.addView(micHost, LinearLayout.LayoutParams(Ui.dp(this, 64), Ui.dp(this, 64)))

        val pill = Ui.row(this)
        pill.background = Ui.round(Color.WHITE, Ui.dpf(this, 28f), Ui.P200, Ui.dp(this, 1))
        pill.elevation = Ui.dpf(this, 3f)
        pill.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4))
        input = EditText(this).apply {
            hint = "พิมพ์คำสั่ง เช่น ส่งไลน์หาแม่ว่าถึงบ้านแล้ว…"
            setHintTextColor(0xFF9C94B8.toInt()); setTextColor(Ui.TEXT); textSize = 15.5f
            background = null; maxLines = 4
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        pill.addView(input, Ui.lp(0, weight = 1f))
        val sendBtn = TextView(this).apply {
            text = "➤"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = Ui.ripple(Ui.oval(Ui.P500, Ui.P700), 0x55FFFFFF)
            setOnClickListener {
                Fx.press(this)
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) { input.setText(""); send(t) }
            }
        }
        pill.addView(sendBtn, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)))
        bar.addView(pill, Ui.lp(0, weight = 1f).apply { marginStart = Ui.dp(this@MainActivity, 6) })
        return bar
    }

    // ------------------------------------------------------------------ วงจรชีวิต
    override fun onResume() {
        super.onResume()
        visible = true
        current = this
        ChatLog.listen(listener)
        rendered.clear()
        list.removeAllViews()
        render()
        BotService.start(this)                // ยืนยันบริการเบื้องหน้า (ให้ไมค์ทำงานตอนแอปเปิดอยู่)
        Updater.check(this, false)            // มีเวอร์ชันใหม่บน GitHub → ถามอัปเดตทับ
    }

    override fun onPause() {
        ChatLog.unlisten(listener)
        visible = false
        current = null
        super.onPause()
    }

    // ------------------------------------------------------------------ แสดงผล
    private fun refreshStatus() {
        val s = try { JSONObject(Bridge.status()) } catch (_: Exception) { return }
        chips.removeAllViews()
        fun chip(k: String, name: String) {
            val ok = s.optBoolean(k)
            val c = Ui.chip(this, (if (ok) "✓ " else "! ") + name, false) { startActivity(Intent(this, SetupActivity::class.java)) }
            if (!ok) c.background = Ui.round(0x66F59E0B, Ui.dpf(this, 20f))
            chips.addView(c, Ui.lpm(this, w = ViewGroup.LayoutParams.WRAP_CONTENT, e = 8))
        }
        chip("bot", "บอท"); chip("a11y", "คุมจอ"); chip("notif", "แจ้งเตือน"); chip("mic", "ไมค์")
        val mood = listOf(ChatLog.moodTitle, ChatLog.moodText).filter { it.isNotBlank() }.joinToString(" · ")
        val on = Bridge.isEnabled()
        power.background = Ui.ripple(GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(if (on) 0xFF22C55E.toInt() else 0x55FFFFFF)
        }, 0x55FFFFFF)
        orb.alpha = if (on) 1f else 0.45f
        subtitle.text = when {
            !on -> "⏸️ ปิดอยู่ — แตะ ⏻ เพื่อเปิด"
            mood.isNotEmpty() -> mood
            !s.optBoolean("a11y") -> "แตะ 🔐 เปิดสิทธิ์ 'คุมจอ' ก่อนนะ"
            else -> "พร้อมรับคำสั่ง ✨"
        }
    }

    private fun welcome(): View {
        val c = Ui.card(this, 20, 24)
        c.gravity = Gravity.CENTER_HORIZONTAL
        val o = TextView(this).apply { text = "✨"; textSize = 34f; gravity = Gravity.CENTER; background = Ui.oval(Ui.P400, Ui.PINK) }
        c.addView(o, LinearLayout.LayoutParams(Ui.dp(this, 78), Ui.dp(this, 78)).apply { bottomMargin = Ui.dp(this@MainActivity, 12) })
        Fx.breathe(o, 1.1f, 1300)
        c.addView(Ui.text(this, "สวัสดีครับ มีอะไรให้ช่วยไหม", 19f, true, Ui.P700).apply { gravity = Gravity.CENTER })
        c.addView(Ui.text(this, "พิมพ์ กด 🎤 พูดว่า \"เฮ้ย ผู้ช่วย\" หรือสั่งผ่าน Telegram ก็ได้\nลองแตะทางลัดด้านบนดูได้เลย", 14f, false, Ui.SUB)
            .apply { gravity = Gravity.CENTER }, Ui.lpm(this, t = 6))
        c.layoutParams = Ui.lpm(this, t = 20, s = 12, e = 12)
        return c
    }

    private fun bubble(m: ChatLog.Msg): View {
        val a = this
        if (m.role == "status") {
            val t = Ui.text(a, m.text, 12.5f, false, Ui.P600).apply {
                background = Ui.round(Ui.P100, Ui.dpf(a, 14f))
                setPadding(Ui.dp(a, 12), Ui.dp(a, 5), Ui.dp(a, 12), Ui.dp(a, 5))
            }
            t.layoutParams = Ui.lpm(a, w = ViewGroup.LayoutParams.WRAP_CONTENT, t = 8).apply { gravity = Gravity.CENTER_HORIZONTAL }
            return t
        }
        val user = m.role == "user"
        val r = Ui.dpf(a, 20f); val s = Ui.dpf(a, 6f)
        val tv = Ui.text(a, m.text, 15.5f, false, if (user) Color.WHITE else Ui.TEXT).apply {
            setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10))
            setTextIsSelectable(false)
            background = if (user)
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Ui.P500, Ui.PINK)).apply { cornerRadii = floatArrayOf(r, r, r, r, s, s, r, r) }
            else Ui.corners(Color.WHITE, s, r, r, r)
            elevation = Ui.dpf(a, if (user) 3f else 1.5f)
            setOnLongClickListener {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("chat", m.text))
                Popups.snack(a, "📋 คัดลอกแล้ว"); true
            }
        }
        val wrap = Ui.col(a, 0)
        val line = Ui.row(a)
        line.gravity = if (user) Gravity.END else Gravity.START or Gravity.TOP
        if (!user) {
            val av = TextView(a).apply { text = "✨"; textSize = 14f; gravity = Gravity.CENTER; background = Ui.oval(Ui.P400, Ui.PINK) }
            line.addView(av, LinearLayout.LayoutParams(Ui.dp(a, 30), Ui.dp(a, 30)).apply { marginEnd = Ui.dp(a, 8) })
        }
        val maxW = (resources.displayMetrics.widthPixels * 0.78).toInt()
        tv.maxWidth = maxW
        line.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        wrap.addView(line, Ui.lp())
        wrap.addView(Ui.text(a, timeFmt.format(Date(m.time)), 10.5f, false, 0xFFA59CC4.toInt()).apply {
            gravity = if (user) Gravity.END else Gravity.START
            setPadding(if (user) 0 else Ui.dp(a, 40), Ui.dp(a, 2), Ui.dp(a, 4), 0)
        }, Ui.lp())
        wrap.layoutParams = Ui.lpm(a, t = 10)
        return wrap
    }

    private fun render() {
        val items = ChatLog.items.toList()
        if (items.isEmpty()) {
            if (rendered.isNotEmpty() || list.childCount == 0) { list.removeAllViews(); rendered.clear(); list.addView(welcome()) }
        } else {
            if (rendered.isEmpty()) list.removeAllViews()          // เอาการ์ดต้อนรับออก
            var common = 0
            while (common < rendered.size && common < items.size && rendered[common] === items[common]) common++
            while (rendered.size > common) {
                list.removeViewAt(list.childCount - 1); rendered.removeAt(rendered.size - 1)
            }
            for (i in common until items.size) {
                val v = bubble(items[i])
                list.addView(v)
                rendered.add(items[i])
                if (i >= items.size - 3) Fx.enter(v, items[i].role == "user")
            }
        }
        val last = items.lastOrNull()
        val thinking = busy.get() > 0 || ChatLog.moodTitle.isNotBlank()
        typing.visibility = if (thinking) View.VISIBLE else View.GONE
        typingText.text = when {
            ChatLog.moodTitle.isNotBlank() -> ChatLog.moodTitle
            last?.role == "status" -> last?.text?.take(60) ?: ""
            else -> "กำลังคิด…"
        }
        scroll.post { scroll.smoothScrollTo(0, list.height) }
        renderPrompts()
        refreshStatus()
    }

    /** คำถาม/ขออนุญาต → ป๊อปอัปแผ่นเด้ง */
    private fun renderPrompts() {
        val ids = ChatLog.prompts.map { it.id }.toSet()
        for (id in dialogs.keys.toList()) if (id !in ids) { dialogs.remove(id)?.let { if (it.isShowing) it.dismiss() } }
        for (p in ChatLog.prompts) {
            if (dialogs.containsKey(p.id) || isFinishing) continue
            dialogs[p.id] = if (p.kind == "confirm") Popups.confirm(this, p.id, p.text) else Popups.ask(this, p.id, p.text)
        }
    }

    // ------------------------------------------------------------------ การกระทำ
    private fun prefill(t: String) {
        input.setText(t); input.setSelection(t.length); input.requestFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.showSoftInput(input, 0)
    }

    private fun send(text: String) {
        if (!Bridge.isEnabled()) {
            Popups.snack(this, "⏸️ ผู้ช่วยปิดอยู่ — แตะ ⏻ ด้านบนเพื่อเปิด"); return
        }
        ChatLog.add("user", text)
        busy.incrementAndGet(); render()
        worker.execute {
            try {
                val reply = App.py(this).getModule("android_main").callAttr("chat", text).toString()
                if (reply.isNotBlank()) ChatLog.add("bot", reply)
            } catch (e: Throwable) {
                ChatLog.add("bot", "❗ ผิดพลาด: ${e.message?.take(300)}")
            } finally {
                busy.decrementAndGet()
                runOnUiThread { render() }
            }
        }
    }

    private fun setListening(on: Boolean) {
        micAnims.forEach { it.cancel() }
        micAnims = if (on) Fx.ripples(micHost, this, 54) else emptyList()
        micBtn.text = if (on) "🎙️" else "🎤"
        if (on) ChatLog.setMood("🎙️ กำลังฟัง…", "พูดได้เลย", true) else if (ChatLog.moodTitle.startsWith("🎙️")) ChatLog.setMood("", "", false)
    }

    private fun listenOnce() {
        if (!Bridge.isEnabled()) { Popups.snack(this, "⏸️ ผู้ช่วยปิดอยู่ — แตะ ⏻ ด้านบนเพื่อเปิด"); return }
        if (!Bridge.micAllowed()) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 5); return
        }
        setListening(true)
        Thread {
            var err: String? = null
            val heard = try {
                App.py(this).getModule("android_main").callAttr("listen_once").toString()
            } catch (e: Throwable) {
                err = e.message?.substringAfterLast("Error: ")?.take(220); ""
            }
            runOnUiThread {
                setListening(false)
                when {
                    heard.isNotBlank() -> send(heard)
                    err != null -> Popups.info(this, "🎤", "ยังไม่ได้ยิน", err ?: "")
                    else -> Popups.snack(this, "🎤 ไม่ได้ยินเสียงพูด ลองอีกครั้ง")
                }
            }
        }.start()
    }

    private fun help() {
        Popups.info(this, "📋", "ผู้ช่วยทำอะไรได้บ้าง", """• เปิด youtube / ปิดแอป line / กลับหน้าหลัก
• ส่งไลน์หาแม่ว่า ถึงบ้านแล้ว / ส่งรูปล่าสุดให้ต้นในไอจี
• มีแจ้งเตือนอะไรบ้าง / ตอบกลับว่า โอเค
• ลดเสียง / เพิ่มแสง / เปิดห้ามรบกวน / ไฟฉาย
• หาข่าววันนี้ / สรุปไฟล์นี้ / ช่วยแปล…
• กรอกฟอร์ม / จำข้อมูลของฉัน ชื่อ …
• ศึกษาแอป instagram / จำขั้นตอน … → จบขั้นตอน → ทำขั้นตอน …
• ตรวจซ่อม / ซ่อมตัวเอง <อาการ> / ย้อนการซ่อม
• ฟังตลอด / ปิดฟังตลอด / สลับไปใช้ claude""")
    }
}
