package com.aibot.assistant

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** ธีมม่วง-ขาว + ตัวช่วยสร้างหน้าจอด้วยโค้ด + แอนิเมชัน */
object Ui {
    // ---------------------------------------------------------------- สี
    const val P900 = 0xFF2E1065.toInt()
    const val P700 = 0xFF5B21B6.toInt()
    const val P600 = 0xFF6D28D9.toInt()
    const val P500 = 0xFF7C3AED.toInt()
    const val P400 = 0xFF8B5CF6.toInt()
    const val P300 = 0xFFC4B5FD.toInt()
    const val P200 = 0xFFDDD6FE.toInt()
    const val P100 = 0xFFEDE9FE.toInt()
    const val P50 = 0xFFF7F4FF.toInt()
    const val PINK = 0xFFC026D3.toInt()
    const val WHITE = Color.WHITE
    const val TEXT = 0xFF241640.toInt()
    const val SUB = 0xFF6E6390.toInt()
    const val OK = 0xFF16A34A.toInt()
    const val WARN = 0xFFF59E0B.toInt()
    const val BAD = 0xFFE11D48.toInt()
    const val ACCENT = P500

    // ใช้กับโค้ดเดิม
    fun bg(c: Context) = P50
    fun fg(c: Context) = TEXT

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()
    fun dpf(c: Context, v: Float): Float = v * c.resources.displayMetrics.density

    // ---------------------------------------------------------------- พื้นหลัง
    fun round(color: Int, r: Float, stroke: Int = 0, strokeW: Int = 2): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = r; if (stroke != 0) setStroke(strokeW, stroke) }

    fun grad(r: Float, vararg colors: Int, orient: GradientDrawable.Orientation = GradientDrawable.Orientation.TL_BR) =
        GradientDrawable(orient, colors).apply { cornerRadius = r }

    fun corners(color: Int, tl: Float, tr: Float, br: Float, bl: Float) = GradientDrawable().apply {
        setColor(color); cornerRadii = floatArrayOf(tl, tl, tr, tr, br, br, bl, bl)
    }

    fun ripple(content: Drawable, rippleColor: Int = 0x337C3AED): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(rippleColor), content, null)

    fun oval(vararg colors: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
        shape = GradientDrawable.OVAL
    }

    fun statusBar(a: Activity, color: Int = P600) {
        a.window.statusBarColor = color
        a.window.navigationBarColor = WHITE
        @Suppress("DEPRECATION")
        a.window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }

    // ---------------------------------------------------------------- วิว
    fun col(c: Context, pad: Int = 12): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(c, pad); setPadding(p, p, p, p)
    }

    fun row(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun text(c: Context, s: String, size: Float = 15f, bold: Boolean = false, color: Int? = null): TextView =
        TextView(c).apply {
            text = s; textSize = size; setTextColor(color ?: TEXT)
            if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setLineSpacing(0f, 1.12f)
        }

    /** การ์ดขาวมุมโค้ง มีเงา */
    fun card(c: Context, pad: Int = 14, radius: Int = 18): LinearLayout = col(c, pad).apply {
        background = round(WHITE, dpf(c, radius.toFloat()))
        elevation = dpf(c, 3f)
    }

    /** ปุ่ม: primary = ไล่สีม่วง / ปกติ = ขาวขอบม่วง */
    fun button(c: Context, s: String, primary: Boolean = false, onClick: () -> Unit): TextView = TextView(c).apply {
        text = s; textSize = 14.5f; gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val r = dpf(c, 24f)
        if (primary) {
            setTextColor(WHITE)
            background = ripple(grad(r, P500, PINK, orient = GradientDrawable.Orientation.LEFT_RIGHT), 0x55FFFFFF)
            elevation = dpf(c, 3f)
        } else {
            setTextColor(P600)
            background = ripple(round(WHITE, r, P300, dp(c, 1)))
        }
        setPadding(dp(c, 18), dp(c, 10), dp(c, 18), dp(c, 10))
        isClickable = true
        setOnClickListener { Fx.press(this); onClick() }
    }

    /** ชิปเล็ก (ทางลัด / สถานะ) */
    fun chip(c: Context, s: String, light: Boolean = true, onClick: (() -> Unit)? = null): TextView = TextView(c).apply {
        text = s; textSize = 13.5f
        setTextColor(if (light) P700 else WHITE)
        background = ripple(round(if (light) P100 else 0x33FFFFFF, dpf(c, 20f)))
        setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8))
        if (onClick != null) { isClickable = true; setOnClickListener { Fx.press(this); onClick() } }
    }

    /** ปุ่มไอคอนกลม */
    fun iconBtn(c: Context, emoji: String, size: Int = 44, bgColor: Int = 0x33FFFFFF, onClick: () -> Unit): TextView =
        TextView(c).apply {
            text = emoji; textSize = 18f; gravity = Gravity.CENTER
            background = ripple(GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bgColor) }, 0x55FFFFFF)
            layoutParams = LinearLayout.LayoutParams(dp(c, size), dp(c, size)).apply { marginStart = dp(c, 6) }
            isClickable = true
            setOnClickListener { Fx.press(this); onClick() }
        }

    fun input(c: Context, hint: String, multi: Boolean = false, secret: Boolean = false): EditText = EditText(c).apply {
        this.hint = hint
        setTextColor(TEXT); setHintTextColor(0xFF9C94B8.toInt()); textSize = 15f
        inputType = when {
            secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            multi -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            else -> InputType.TYPE_CLASS_TEXT
        }
        if (!multi) maxLines = 1
        background = round(P50, dpf(c, 14f), P200, dp(c, 1))
        setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10))
    }

    /** ปุ่มเลือกแบบแถว (เลือกได้อันเดียว) */
    fun segmented(c: Context, options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit): LinearLayout {
        val r = row(c)
        fun paint() {
            for (i in 0 until r.childCount) {
                val v = r.getChildAt(i) as TextView
                val on = v.tag == r.tag
                v.setTextColor(if (on) WHITE else P700)
                v.background = if (on) grad(dpf(c, 20f), P500, PINK, orient = GradientDrawable.Orientation.LEFT_RIGHT)
                               else round(P100, dpf(c, 20f))
            }
        }
        r.tag = selected
        for ((value, label) in options) {
            val t = TextView(c).apply {
                text = label; textSize = 13.5f; tag = value; gravity = Gravity.CENTER
                setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8))
                setOnClickListener { r.tag = value; paint(); Fx.press(this); onPick(value) }
            }
            r.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginEnd = dp(c, 6); bottomMargin = dp(c, 6) })
        }
        paint()
        return r
    }

    fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
           weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

    fun lpm(c: Context, w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
            t: Int = 0, b: Int = 0, s: Int = 0, e: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(c, t); bottomMargin = dp(c, b); marginStart = dp(c, s); marginEnd = dp(c, e) }

    fun gap(c: Context, h: Int = 8): View = View(c).apply { layoutParams = lp(h = dp(c, h)) }

    /** หัวหน้าจอแบบไล่สีม่วง มุมล่างโค้ง (ใช้กับทุกหน้า) */
    fun header(a: Activity, title: String, subtitle: String, back: Boolean = true): LinearLayout {
        val h = col(a, 0)
        h.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(P700, P500, PINK)).apply {
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dpf(a, 28f), dpf(a, 28f), dpf(a, 28f), dpf(a, 28f))
        }
        h.setPadding(dp(a, 18), dp(a, 14), dp(a, 18), dp(a, 20))
        val r = row(a)
        if (back) r.addView(iconBtn(a, "←", 40) { a.finish() }.apply {
            setTextColor(WHITE); (layoutParams as LinearLayout.LayoutParams).marginStart = 0
            (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(a, 10)
        })
        val tt = col(a, 0)
        tt.addView(text(a, title, 22f, true, WHITE))
        tt.addView(text(a, subtitle, 13f, false, 0xDDFFFFFF.toInt()))
        r.addView(tt, lp(0, weight = 1f))
        h.addView(r)
        return h
    }
}

/** แอนิเมชัน */
object Fx {
    fun press(v: View) {
        v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(70).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(OvershootInterpolator(3f)).start()
        }.start()
    }

    /** เลื่อนขึ้น + จางเข้า (ข้อความใหม่) */
    fun enter(v: View, fromRight: Boolean = false, delay: Long = 0) {
        v.alpha = 0f
        v.translationY = 28f
        v.translationX = if (fromRight) 40f else -40f
        v.scaleX = 0.94f; v.scaleY = 0.94f
        v.animate().alpha(1f).translationY(0f).translationX(0f).scaleX(1f).scaleY(1f)
            .setStartDelay(delay).setDuration(320).setInterpolator(DecelerateInterpolator(1.6f)).start()
    }

    fun pop(v: View) {
        v.scaleX = 0.7f; v.scaleY = 0.7f; v.alpha = 0f
        v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(320).setInterpolator(OvershootInterpolator(1.6f)).start()
    }

    /** หายใจ (วงกลมสถานะ) */
    fun breathe(v: View, scale: Float = 1.08f, ms: Long = 1400): ObjectAnimator =
        ObjectAnimator.ofPropertyValuesHolder(v,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, scale),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, scale)).apply {
            duration = ms; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start()
        }

    /** คลื่นกระจายรอบปุ่มไมค์ตอนฟัง */
    fun ripples(host: FrameLayout, c: Context, sizeDp: Int): List<Animator> {
        val out = ArrayList<Animator>()
        for (i in 0 until 3) {
            val ring = View(c)
            ring.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x557C3AED) }
            val s = Ui.dp(c, sizeDp)
            host.addView(ring, 0, FrameLayout.LayoutParams(s, s, Gravity.CENTER))
            val a = ObjectAnimator.ofPropertyValuesHolder(ring,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 2.1f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 2.1f),
                PropertyValuesHolder.ofFloat(View.ALPHA, 0.8f, 0f)).apply {
                duration = 1500; startDelay = i * 500L; repeatCount = ValueAnimator.INFINITE
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationCancel(animation: Animator) { host.removeView(ring) }
                })
                start()
            }
            out.add(a)
        }
        return out
    }

    /** จุดสามจุดเด้ง (กำลังพิมพ์) */
    fun typingDots(c: Context): Pair<LinearLayout, List<Animator>> {
        val r = Ui.row(c)
        val anims = ArrayList<Animator>()
        for (i in 0 until 3) {
            val d = View(c)
            d.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Ui.P400) }
            val s = Ui.dp(c, 8)
            r.addView(d, LinearLayout.LayoutParams(s, s).apply { marginEnd = Ui.dp(c, 5) })
            anims.add(ObjectAnimator.ofFloat(d, View.TRANSLATION_Y, 0f, -Ui.dpf(c, 6f), 0f).apply {
                duration = 600; startDelay = i * 150L; repeatCount = ValueAnimator.INFINITE; start()
            })
        }
        return Pair(r, anims)
    }

    /** ไล่สีพื้นหลังเปลี่ยนไปมาช้าๆ */
    fun shimmer(d: GradientDrawable, a: Int, b: Int, c2: Int): ValueAnimator =
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 5000; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            val ev = android.animation.ArgbEvaluator()
            addUpdateListener {
                val f = it.animatedValue as Float
                d.colors = intArrayOf(ev.evaluate(f, a, b) as Int, ev.evaluate(f, b, c2) as Int, ev.evaluate(f, c2, a) as Int)
            }
            start()
        }
}
