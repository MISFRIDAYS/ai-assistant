"""จำเสียงเจ้าของเครื่อง (ทำงานในเครื่อง ไม่ส่งเสียงไปไหน) — ใช้กรองให้บอทฟังเฉพาะเสียงคุณ

วิธี: แปลงเสียงเป็น "ลายเสียง" (MFCC: ลักษณะช่องเสียง/โทนเสียงของแต่ละคน) แล้วเทียบกับเสียงที่บันทึกไว้ตอนสอน
ข้อจำกัด: แยกเสียงคนละคน/ทีวี/เพลงได้ดี แต่คนเสียงคล้ายกันมาก (เช่น พี่น้อง) อาจหลุดผ่านได้บ้าง

สอนเสียง: bash enroll_voice.sh (พูด 6 ประโยค ~1 นาที)
ไฟล์: data/voiceprint.json
"""
import json
import os

import config

RATE = 16000
N_MFCC = 20
_cache = {"prof": None, "mtime": 0}


def available():
    try:
        import numpy  # noqa: F401
        return True
    except ImportError:
        return False


def _path():
    return os.path.join(config.DATA_DIR, "voiceprint.json")


def _mel_filters(n_fft=512, n_mels=40, fmin=60, fmax=7600):
    import numpy as np
    def hz2mel(h):
        return 2595 * np.log10(1 + h / 700.0)

    def mel2hz(m):
        return 700 * (10 ** (m / 2595.0) - 1)
    mels = np.linspace(hz2mel(fmin), hz2mel(fmax), n_mels + 2)
    bins = np.floor((n_fft + 1) * mel2hz(mels) / RATE).astype(int)
    fb = np.zeros((n_mels, n_fft // 2 + 1))
    for i in range(1, n_mels + 1):
        a, b, c = bins[i - 1], bins[i], bins[i + 1]
        for k in range(a, b):
            fb[i - 1, k] = (k - a) / max(1, b - a)
        for k in range(b, c):
            fb[i - 1, k] = (c - k) / max(1, c - b)
    return fb


def features(pcm):
    """PCM 16-bit 16kHz → เวกเตอร์ลายเสียง (หรือ None ถ้าเสียงพูดสั้นเกินไป)"""
    import numpy as np
    x = np.frombuffer(pcm, dtype=np.int16).astype(np.float32)
    if len(x) < RATE * 0.6:
        return None
    x = np.append(x[0], x[1:] - 0.97 * x[:-1])                     # pre-emphasis
    flen, hop, n_fft = 400, 160, 512
    n = 1 + (len(x) - flen) // hop
    idx = np.arange(flen)[None, :] + hop * np.arange(n)[:, None]
    frames = x[idx] * np.hamming(flen)
    energy = (frames ** 2).sum(axis=1)
    keep = energy > np.percentile(energy, 40)                       # เฉพาะช่วงที่มีเสียงพูด
    frames = frames[keep]
    if len(frames) < 40:
        return None
    pw = np.abs(np.fft.rfft(frames, n_fft)) ** 2 / n_fft
    mel = np.log(pw @ _mel_filters(n_fft).T + 1e-6)
    k = np.arange(mel.shape[1])
    dct = np.cos(np.pi / mel.shape[1] * (k[None, :] + 0.5) * np.arange(N_MFCC + 1)[:, None])
    mfcc = (mel @ dct.T)[:, 1:]                                    # ตัด c0 (ความดัง) ทิ้ง
    delta = np.diff(mfcc, axis=0)
    return np.concatenate([mfcc.mean(0), mfcc.std(0), delta.std(0)])


def _load():
    p = _path()
    try:
        m = os.path.getmtime(p)
    except OSError:
        return None
    if _cache["prof"] is None or m != _cache["mtime"]:
        with open(p, encoding="utf-8") as f:
            _cache["prof"] = json.load(f)
        _cache["mtime"] = m
    return _cache["prof"]


def enrolled():
    return available() and _load() is not None


def _score(v, prof):
    import numpy as np
    mu, sd = np.array(prof["mean"]), np.array(prof["std"])
    z = (v - mu) / sd
    a, b = z, np.zeros_like(z)
    # ระยะห่างแบบปรับสเกล → แปลงเป็นคะแนน 0-1 (1 = เหมือนมาก)
    return float(1.0 / (1.0 + np.sqrt((a - b) @ (a - b) / len(a))))


def enroll(samples):
    """samples = list ของ PCM ประโยคต่างๆ จากเจ้าของ → บันทึกลายเสียง + เกณฑ์อัตโนมัติ"""
    import numpy as np
    vecs = [v for v in (features(s) for s in samples) if v is not None]
    if len(vecs) < 3:
        raise ValueError("เสียงสั้น/เบาเกินไป ได้ตัวอย่างไม่พอ (ต้องการอย่างน้อย 3 ประโยค)")
    V = np.array(vecs)
    mu = V.mean(0)
    sd = V.std(0) + np.abs(mu) * 0.08 + 0.5                        # กันหารด้วยค่าเล็กเกิน
    prof = {"mean": mu.tolist(), "std": sd.tolist(), "n": len(vecs)}
    scores = []
    for i in range(len(vecs)):                                     # ทดสอบแบบไม่รวมตัวเอง
        rest = np.delete(V, i, axis=0)
        p = {"mean": rest.mean(0).tolist(),
             "std": (rest.std(0) + np.abs(rest.mean(0)) * 0.08 + 0.5).tolist()}
        scores.append(_score(V[i], p))
    prof["self"] = scores
    prof["threshold"] = round(max(0.2, min(scores) - 0.10), 3)   # เผื่อเสียงจริงต่างจากตอนสอน (ระยะ/เสียงรอบข้าง)
    os.makedirs(config.DATA_DIR, exist_ok=True)
    with open(_path(), "w", encoding="utf-8") as f:
        json.dump(prof, f)
    _cache["prof"] = None
    return prof


def check(pcm):
    """คืน (เป็นเจ้าของไหม, คะแนน) — ถ้ายังไม่ได้สอนเสียง/ไม่มี numpy ถือว่าผ่าน"""
    prof = _load() if available() else None
    if not prof:
        return True, None
    v = features(pcm)
    if v is None:
        return True, None                                          # สั้นเกินตัดสิน → ไม่บล็อก
    s = _score(v, prof)
    th = prof["threshold"] + config.SPEAKER_STRICT
    return s >= th, round(s, 3)


def forget():
    try:
        os.remove(_path())
    except OSError:
        pass
