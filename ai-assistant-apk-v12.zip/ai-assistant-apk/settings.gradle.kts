pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "AiBot"
include(":app")
project(":app").projectDir = file("aibot-app/app")   // เปิดโฟลเดอร์นอกสุดก็ build ได้
