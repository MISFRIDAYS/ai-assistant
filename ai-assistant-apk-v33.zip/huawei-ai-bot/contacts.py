"""จำว่าแต่ละคนคุยกันในแอปไหน — "ส่งข้อความหาภรรยา(คนเจก) ว่า…" ไม่ต้องบอกว่า instagram

เรียนรู้จาก: ส่งข้อความ/โทรสำเร็จ (น้ำหนักมาก) · แจ้งเตือนที่คนนั้นทักมา (น้ำหนักน้อย) · ผู้ใช้สอน "ภรรยาอยู่ในไอจี"
ข้อมูลอยู่ที่ data/contacts.json (ในเครื่อง)
"""
import json
import os
import re
import threading
import time

import config

_PATH = os.path.join(config.DATA_DIR, "contacts.json")
_lock = threading.RLock()
_db = {"d": None}
WEIGHT = {"sent": 5.0, "call": 5.0, "taught": 50.0, "notif": 1.0}
APP_KEYS = {"jp.naver.line.android": "line", "com.facebook.orca": "messenger", "com.instagram.android": "instagram",
            "com.whatsapp": "whatsapp", "org.telegram.messenger": "telegram", "com.facebook.katana": "facebook",
            "com.google.android.apps.messaging": "sms", "com.android.mms": "sms", "com.huawei.message": "sms",
            "com.discord": "discord", "com.viber.voip": "viber", "com.tencent.mm": "wechat"}
APP_WORDS = {"line": r"ไลน์|line", "instagram": r"ไอจี|อินสตา(?:แกรม)?|instagram|ig", "messenger": r"เมสเซนเจอร์|เมสเซ็นเจอร์|messenger|แชทเฟส",
             "facebook": r"เฟส(?:บุ๊ค|บุ๊ก)?|facebook", "whatsapp": r"วอทส์?แอป|whatsapp", "telegram": r"เทเลแกรม|telegram",
             "sms": r"sms|ข้อความมือถือ"}


def norm(name):
    return re.sub(r"[\s\-_.()（）\[\]]+", "", (name or "").lower())


def _load():
    with _lock:
        if _db["d"] is None:
            try:
                with open(_PATH, encoding="utf-8") as f:
                    _db["d"] = json.load(f)
            except (OSError, ValueError):
                _db["d"] = {}
        return _db["d"]


def _save():
    with _lock:
        os.makedirs(os.path.dirname(_PATH), exist_ok=True)
        tmp = _PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_load(), f, ensure_ascii=False)
        os.replace(tmp, _PATH)


def learn(name, app, how="sent"):
    """จำว่าคนนี้อยู่ในแอปนี้"""
    app = APP_KEYS.get(app, app)
    k = norm(name)
    if not k or len(k) < 2 or not app or len(k) > 40:
        return
    with _lock:
        e = _load().setdefault(k, {"name": name.strip(), "apps": {}, "last": "", "t": 0})
        e["apps"][app] = round(e["apps"].get(app, 0) + WEIGHT.get(how, 1.0), 1)
        if how in ("sent", "call", "taught"):
            e["last"], e["name"] = app, name.strip()
        e["t"] = time.time()
        if len(_load()) > 3000:                           # ลบคนที่นานมากแล้ว
            for old in sorted(_load(), key=lambda x: _load()[x].get("t", 0))[:300]:
                _load().pop(old, None)
    if how != "notif":
        _save()


def flush():
    _save()


def app_for(name):
    """แอปที่คุยกับคนนี้บ่อยที่สุด (หรือ None)"""
    d = _load()
    k = norm(name)
    if not k:
        return None
    e = d.get(k)
    if not e:                                             # ชื่อสั้น/ยาวกว่าที่จำ เช่น "ภรรยา" ↔ "ภรรยา(คนเจก)"
        cands = [v for kk, v in d.items() if len(k) >= 3 and (k in kk or kk in k)]
        if len(cands) != 1:
            return None
        e = cands[0]
    if e.get("last") and e["apps"].get(e["last"], 0) >= max(e["apps"].values()) * 0.5:
        return e["last"]
    return max(e["apps"], key=e["apps"].get) if e.get("apps") else None


def known_name(name):
    """ชื่อเต็มที่จำไว้ เช่น 'ภรรยา' → 'ภรรยา(คนเจก)'"""
    d = _load()
    k = norm(name)
    if k in d:
        return d[k]["name"]
    cands = [v["name"] for kk, v in d.items() if len(k) >= 3 and (k in kk or kk in k)]
    return cands[0] if len(cands) == 1 else None


_TEACH = re.compile(r"^(?:จำไว้ว่า)?\s*(?P<n>.+?)\s*(?:อยู่|คุย(?:กัน)?|ใช้|ติดต่อ)(?:ใน|ทาง|ผ่าน)\s*(?:แอป)?\s*(?P<a>" +
                    "|".join(APP_WORDS.values()) + r")\s*(?:นะ|น่ะ|ครับ)?$", re.I)


def handle_text(text, ctx=None):
    t = " ".join(re.sub(r"\[[^\]]*\]", " ", text or "").split()).strip()
    m = _TEACH.match(t)
    if not m:
        return None
    app = next(k for k, rx in APP_WORDS.items() if re.fullmatch(rx, m.group("a"), re.I))
    learn(m.group("n"), app, "taught")
    return f"👌 จำแล้ว — {m.group('n')} คุยใน {app} ครั้งหน้าสั่งแค่ \"ส่งหา {m.group('n')} ว่า…\" ได้เลย"
